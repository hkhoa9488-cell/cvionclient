PVPClient 1.21.11 - REAL FABRIC BUILD

This project is configured for Minecraft 1.21.11 + Java 21 + Fabric Loader 0.18.1 + Fabric API 0.141.6+1.21.11.

IMPORTANT:
- The previous build failed because build.gradle used the wrong plugin ID:
  net.fabricmc.fabric-loom-remap
- This version uses the valid legacy/remapping Loom plugin ID:
  fabric-loom
- Loom 1.13.6 is the remapping Loom line for Minecraft 1.21.11.
- BUILD-JAR.bat checks for Java 21 and downloads Gradle 8.14.3 if needed.
- It reports BUILD SUCCESS only when a JAR is actually present in build\libs.

Run:
1. Extract the whole ZIP.
2. Run BUILD-JAR.bat.
3. Put the generated pvpclient-0.1.0.jar into your Fabric 1.21.11 mods folder.

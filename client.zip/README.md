# PVP Client — Fabric 1.21.11

Client-side PvP utility foundation designed for Minecraft 1.21.11 and structured for future version ports.

## Modules

### Combat
- Spear Swap / Lunge detection
- Optional automatic Mace swap after detected Lunge window
- Elytra -> best hotbar chestplate swap when flight ends and the player starts falling

### Movement
- Smart Auto Sprint

### Profile / HUD
- CPS
- Keystrokes
- Armor status
- Active effect status
- Animated RGB accent
- In-game hub screen with tabs and toggles

### Music
- Direct URL player foundation using the JRE audio mixer (WAV/AIFF/AU)
- The player is isolated so MP3/OGG/stream resolver support can be added later without redesigning the UI

## Controls
- Right Shift: open hub
- Spear / armor / sprint modules can also be bound from Minecraft Controls after launch.

## Build

Requirements: JDK 21, Gradle 8.14+.

```bash
gradle build
```

The remapped jar is produced under `build/libs/`.

## Versioning strategy

Minecraft 1.21.11 is the final obfuscated Minecraft release in this mapping era. The project uses official Mojang mappings now so a later port to 26.x can avoid a Yarn migration. Fabric's documentation recommends official Mojang mappings for this transition.

Future releases should keep feature logic separated from version-specific compatibility code.

## Real Fabric rebuild
This project is intended to be built with Java 21 using the included BUILD-JAR.bat. It uses the real Fabric Loader/Fabric API/Loom dependencies and does not package stub Fabric classes.

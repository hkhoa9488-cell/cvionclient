package com.pvpclient.music;

import com.pvpclient.PvpClient;
import net.minecraft.client.Minecraft;

import javax.sound.sampled.*;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.URI;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Lightweight direct-audio player. WAV/AIFF/au URLs are supported by the JRE mixer.
 *  The player is intentionally isolated so OGG/MP3 decoders can be added later without changing the UI API. */
public final class MusicManager {
    private static final ExecutorService IO = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "pvpclient-audio"); t.setDaemon(true); return t; });
    private static volatile Clip clip;

    public void tick(Minecraft client) { }

    public static void playUrl(String url) {
        if (url == null || url.isBlank()) return;
        stop();
        IO.submit(() -> {
            Clip c = null;
            try (InputStream in = new BufferedInputStream(URI.create(url).toURL().openStream());
                 AudioInputStream audio = AudioSystem.getAudioInputStream(in)) {
                c = AudioSystem.getClip();
                c.open(audio);
                // A newer play request may have already come in and stopped/replaced
                // `clip` while we were opening the stream; don't clobber it back.
                Clip previous = clip;
                if (previous != null) try { previous.close(); } catch (Exception ignored) {}
                clip = c;
                c.start();
            } catch (Exception e) {
                // Logged instead of silently swallowed, so a bad URL / unsupported
                // format / network hiccup is visible in the log instead of just
                // silently doing nothing, which is confusing to debug.
                PvpClient.LOGGER.warn("[pvpclient] Failed to play audio from URL: {}", url, e);
                if (c != null) try { c.close(); } catch (Exception ignored) {}
            }
        });
    }

    public static void stop() {
        Clip c = clip;
        clip = null;
        if (c != null) {
            try { c.stop(); } catch (Exception ignored) {}
            try { c.close(); } catch (Exception ignored) {}
        }
    }
}

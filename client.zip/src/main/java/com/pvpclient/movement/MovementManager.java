package com.pvpclient.movement;

import com.pvpclient.PvpClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

public final class MovementManager {
    public void tick(Minecraft client) {
        LocalPlayer p = client.player;
        if (p == null || !PvpClient.CONFIG.autoSprint) return;
        if (client.screen != null || p.isSpectator()) return;
        if (p.isUsingItem() || p.isCrouching() || p.getDeltaMovement().horizontalDistanceSqr() < 0.001) return;
        if (p.input.hasForwardImpulse()) p.setSprinting(true);
    }
}

package com.pvpclient.combat;

import com.pvpclient.PvpClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.tags.ItemTags;

public final class CombatManager {
    private boolean wasFlying;
    private double lastSpeed;
    private int swapDelay;
    private int previousSlot = -1;
    private boolean lungeWindow;

    public void tick(Minecraft client) {
        Player p = client.player;
        if (p == null || client.level == null) return;

        if (PvpClient.CONFIG.spearSwap) tickSpearSwap(client, p);
        if (PvpClient.CONFIG.elytraAutoArmor) tickElytraArmor(client, p);
    }

    private void tickSpearSwap(Minecraft client, Player p) {
        ItemStack held = p.getMainHandItem();
        boolean spear = held.is(ItemTags.SPEARS);
        double speed = p.getDeltaMovement().horizontalDistanceSqr();
        boolean acceleration = speed > lastSpeed + 0.018 && speed > 0.06;
        lastSpeed = speed;

        if (spear && acceleration && !p.onGround() && !p.isFallFlying()) {
            lungeWindow = true;
            swapDelay = PvpClient.CONFIG.spearSwapDelayTicks;
            previousSlot = p.getInventory().getSelectedSlot();
        }

        if (lungeWindow) {
            if (swapDelay > 0) { swapDelay--; return; }
            if (PvpClient.CONFIG.spearAutoMace) {
                int mace = findHotbar(p, Items.MACE);
                if (mace >= 0 && p.getInventory().getSelectedSlot() != mace) {
                    p.getInventory().setSelectedSlot(mace);
                }
            }
            lungeWindow = false;
        }
    }

    private void tickElytraArmor(Minecraft client, Player p) {
        boolean flying = p.isFallFlying();
        if (wasFlying && !flying && p.getDeltaMovement().y < -0.03 && !p.onGround()) {
            int chest = findBestChestplate(p);
            if (chest >= 0) swapHotbarIntoArmor(client, p, chest, 6);
        }
        wasFlying = flying;
    }

    private int findBestChestplate(Player p) {
        int best = -1;
        int bestScore = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.isEmpty()) continue;
            if (!isChestArmor(s)) continue;
            int score = armorScore(s);
            if (score > bestScore) { bestScore = score; best = i; }
        }
        return best;
    }

    private boolean isChestArmor(ItemStack s) {
        return s.is(Items.LEATHER_CHESTPLATE) || s.is(Items.CHAINMAIL_CHESTPLATE)
                || s.is(Items.IRON_CHESTPLATE) || s.is(Items.GOLDEN_CHESTPLATE)
                || s.is(Items.DIAMOND_CHESTPLATE) || s.is(Items.NETHERITE_CHESTPLATE);
    }

    private int armorScore(ItemStack s) {
        int base = s.is(Items.NETHERITE_CHESTPLATE) ? 600 : s.is(Items.DIAMOND_CHESTPLATE) ? 500
                : s.is(Items.IRON_CHESTPLATE) ? 400 : s.is(Items.GOLDEN_CHESTPLATE) ? 300
                : s.is(Items.CHAINMAIL_CHESTPLATE) ? 200 : 100;
        return base + (s.isDamaged() ? Math.max(0, s.getMaxDamage() - s.getDamageValue()) / 10 : 1000);
    }

    private void swapHotbarIntoArmor(Minecraft client, Player p, int hotbar, int armorSlot) {
        MultiPlayerGameMode mode = client.gameMode;
        if (mode == null || p.containerMenu == null) return;
        mode.handleInventoryMouseClick(p.containerMenu.containerId, armorSlot, hotbar, ClickType.SWAP, p);
    }

    private int findHotbar(Player p, Item item) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(item)) return i;
        return -1;
    }
}

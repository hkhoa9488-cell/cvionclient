package com.pvpclient.hud;

import com.pvpclient.PvpClient;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.EquipmentSlot;

import java.util.ArrayDeque;
import java.util.Deque;

public final class HudManager {
    private final Deque<Long> clicks = new ArrayDeque<>();
    private boolean previousAttack;
    private int ticks;

    public void register() {
        Identifier id = Identifier.fromNamespaceAndPath(PvpClient.MOD_ID, "hud");
        HudElementRegistry.addLast(id, this::render);
    }

    private void render(GuiGraphics g, net.minecraft.client.DeltaTracker delta) {
        // The HUD renders every frame, so any exception here would otherwise spam
        // the log dozens of times a second (or crash rendering entirely). Guard
        // the whole draw so one broken panel just skips a frame instead.
        try {
            if (CONFIG() == null || !CONFIG().hud) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc == null || mc.player == null || mc.options == null || mc.options.hideGui) return;

            boolean attack = mc.options.keyAttack.isDown();
            if (attack && !previousAttack) clicks.addLast(System.currentTimeMillis());
            previousAttack = attack;
            long cutoff = System.currentTimeMillis() - 1000L;
            while (!clicks.isEmpty() && clicks.peekFirst() < cutoff) clicks.removeFirst();
            int cps = clicks.size();

            int color = rgbColor();
            if (CONFIG().cps) drawPanel(g, 8, 8, 72, 28, "CPS", String.valueOf(cps), color);
            if (CONFIG().keystrokes) drawKeys(g, mc, color);
            if (CONFIG().armorStatus) drawArmor(g, mc, color);
            if (CONFIG().effectStatus) drawEffects(g, mc, color);
            ticks++;
        } catch (Throwable t) {
            PvpClient.LOGGER.error("[pvpclient] HUD render error", t);
        }
    }

    private static com.pvpclient.config.ClientConfig CONFIG() { return PvpClient.CONFIG; }

    private void drawPanel(GuiGraphics g, int x, int y, int w, int h, String title, String value, int color) {
        g.fill(x, y, x + w, y + h, 0xB0101020);
        g.fill(x, y, x + w, y + 2, color);
        g.drawString(Minecraft.getInstance().font, title, x + 7, y + 6, 0xFFFFFFFF);
        g.drawString(Minecraft.getInstance().font, value, x + 7, y + 16, color);
    }

    private void drawKeys(GuiGraphics g, Minecraft mc, int color) {
        int x = 8, y = 42, s = 18;
        key(g, mc, "W", x + s, y, mc.options.keyUp.isDown(), color);
        key(g, mc, "A", x, y + s, mc.options.keyLeft.isDown(), color);
        key(g, mc, "S", x + s, y + s, mc.options.keyDown.isDown(), color);
        key(g, mc, "D", x + 2*s, y + s, mc.options.keyRight.isDown(), color);
        key(g, mc, "LMB", x, y + 2*s + 2, mc.options.keyAttack.isDown(), color);
        key(g, mc, "RMB", x + 2*s, y + 2*s + 2, mc.options.keyUse.isDown(), color);
    }

    private void key(GuiGraphics g, Minecraft mc, String text, int x, int y, boolean down, int color) {
        int bg = down ? (color & 0x66FFFFFF) : 0xA0151525;
        g.fill(x, y, x + 17, y + 17, bg);
        g.drawString(mc.font, text, x + 3, y + 4, down ? 0xFFFFFFFF : 0xFFAAAAAA);
    }

    private void drawArmor(GuiGraphics g, Minecraft mc, int color) {
        int x = mc.getWindow().getGuiScaledWidth() - 118, y = 8;
        int i = 0;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack s = mc.player.getItemBySlot(slot);
            if (s.isEmpty()) continue;
            int maxDamage = s.getMaxDamage();
            int pct = (s.isDamageableItem() && maxDamage > 0)
                    ? Math.max(0, 100 - (s.getDamageValue() * 100 / maxDamage))
                    : 100;
            drawPanel(g, x + i * 28, y, 26, 28, "", pct + "%", pct > 25 ? color : 0xFFFF5555);
            i++;
        }
    }

    private void drawEffects(GuiGraphics g, Minecraft mc, int color) {
        int x = mc.getWindow().getGuiScaledWidth() - 150, y = 42;
        int i = 0;
        for (MobEffectInstance effect : mc.player.getActiveEffects()) {
            if (i >= 5) break;
            String name = effect.getEffect().value().getDisplayName().getString();
            int seconds = Math.max(0, effect.getDuration() / 20);
            g.drawString(mc.font, name + " " + seconds + "s", x, y + i * 11, color);
            i++;
        }
    }

    private int rgbColor() {
        if (!PvpClient.CONFIG.rgb) return (PvpClient.CONFIG.accentR << 16) | (PvpClient.CONFIG.accentG << 8) | PvpClient.CONFIG.accentB;
        double t = (System.currentTimeMillis() % 5000L) / 5000.0;
        int r = (int)(128 + 127 * Math.sin(t * Math.PI * 2));
        int g = (int)(128 + 127 * Math.sin(t * Math.PI * 2 + 2.094));
        int b = (int)(128 + 127 * Math.sin(t * Math.PI * 2 + 4.188));
        return (r << 16) | (g << 8) | b;
    }
}

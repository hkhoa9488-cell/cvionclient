package com.pvpclient;

import com.mojang.blaze3d.platform.InputConstants;
import com.pvpclient.combat.CombatManager;
import com.pvpclient.config.ClientConfig;
import com.pvpclient.gui.HubScreen;
import com.pvpclient.hud.HudManager;
import com.pvpclient.movement.MovementManager;
import com.pvpclient.music.MusicManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class PvpClient implements ClientModInitializer {
    public static final String MOD_ID = "pvpclient";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static ClientConfig CONFIG;
    public static KeyMapping OPEN_HUB;
    public static KeyMapping TOGGLE_SPEAR;
    public static KeyMapping TOGGLE_ARMOR;
    public static KeyMapping TOGGLE_SPRINT;

    private CombatManager combat;
    private MovementManager movement;
    private HudManager hud;
    private MusicManager music;

    // Once a subsystem fails repeatedly we stop calling it instead of spamming
    // the log / retrying an operation that will keep throwing every tick.
    private boolean combatDisabled, movementDisabled, musicDisabled;

    @Override
    public void onInitializeClient() {
        try {
            CONFIG = ClientConfig.load();
        } catch (Throwable t) {
            LOGGER.error("[pvpclient] Failed to load config, falling back to defaults", t);
            CONFIG = new ClientConfig();
        }

        try {
            KeyMapping.Category category = new KeyMapping.Category(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
            OPEN_HUB = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.pvpclient.open_hub", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));
            TOGGLE_SPEAR = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.pvpclient.toggle_spear", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, category));
            TOGGLE_ARMOR = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.pvpclient.toggle_armor", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, category));
            TOGGLE_SPRINT = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.pvpclient.toggle_sprint", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, category));
        } catch (Throwable t) {
            LOGGER.error("[pvpclient] Failed to register keybindings", t);
        }

        combat = new CombatManager();
        movement = new MovementManager();
        hud = new HudManager();
        music = new MusicManager();

        try {
            hud.register();
        } catch (Throwable t) {
            LOGGER.error("[pvpclient] Failed to register HUD element", t);
        }

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            try {
                tick(client);
            } catch (Throwable t) {
                // Never let an exception inside our own tick handler propagate:
                // Fabric's event bus runs every listener in the same loop, so an
                // uncaught throwable here would take down other mods' tick logic too.
                LOGGER.error("[pvpclient] Uncaught error in client tick, mod may be unstable", t);
            }
        });
    }

    private void tick(Minecraft client) {
        if (client == null) return;

        try {
            if (OPEN_HUB != null) while (OPEN_HUB.consumeClick()) client.setScreen(new HubScreen());
            if (TOGGLE_SPEAR != null) while (TOGGLE_SPEAR.consumeClick()) CONFIG.spearSwap = !CONFIG.spearSwap;
            if (TOGGLE_ARMOR != null) while (TOGGLE_ARMOR.consumeClick()) CONFIG.elytraAutoArmor = !CONFIG.elytraAutoArmor;
            if (TOGGLE_SPRINT != null) while (TOGGLE_SPRINT.consumeClick()) CONFIG.autoSprint = !CONFIG.autoSprint;
        } catch (Throwable t) {
            LOGGER.error("[pvpclient] Error handling keybindings", t);
        }

        // Each subsystem is isolated: a bug in one (e.g. combat) must not stop
        // movement/music from still ticking, and must not crash the game.
        if (!combatDisabled) {
            try {
                combat.tick(client);
            } catch (Throwable t) {
                combatDisabled = true;
                LOGGER.error("[pvpclient] Combat module crashed, disabling it for this session", t);
            }
        }
        if (!movementDisabled) {
            try {
                movement.tick(client);
            } catch (Throwable t) {
                movementDisabled = true;
                LOGGER.error("[pvpclient] Movement module crashed, disabling it for this session", t);
            }
        }
        if (!musicDisabled) {
            try {
                music.tick(client);
            } catch (Throwable t) {
                musicDisabled = true;
                LOGGER.error("[pvpclient] Music module crashed, disabling it for this session", t);
            }
        }
    }

    public static void saveConfig() {
        try {
            if (CONFIG != null) CONFIG.save();
        } catch (Throwable t) {
            LOGGER.error("[pvpclient] Failed to save config", t);
        }
    }
}

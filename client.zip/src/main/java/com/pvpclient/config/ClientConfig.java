package com.pvpclient.config;

import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.nio.file.*;

public final class ClientConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("pvpclient.properties");
    public boolean spearSwap=true, spearAutoMace=false, elytraAutoArmor=true, autoSprint=true;
    public boolean hud=true, cps=true, keystrokes=true, armorStatus=true, effectStatus=true, rgb=true;
    public int spearSwapDelayTicks=1, accentR=214, accentG=78, accentB=255;
    public float animationSpeed=1.0f;
    public String musicUrl="";

    public static ClientConfig load() {
        ClientConfig c = new ClientConfig();
        try {
            if (Files.exists(FILE)) {
                for (String line : Files.readAllLines(FILE)) {
                    // Each line is parsed independently: one corrupted/unknown line
                    // (e.g. hand-edited by the user, or from a future version) no
                    // longer aborts the rest of the file and silently resets everything.
                    try {
                        String[] a = line.split("=", 2);
                        if (a.length != 2) continue;
                        switch (a[0]) {
                            case "spearSwap" -> c.spearSwap = Boolean.parseBoolean(a[1]);
                            case "spearAutoMace" -> c.spearAutoMace = Boolean.parseBoolean(a[1]);
                            case "elytraAutoArmor" -> c.elytraAutoArmor = Boolean.parseBoolean(a[1]);
                            case "autoSprint" -> c.autoSprint = Boolean.parseBoolean(a[1]);
                            case "hud" -> c.hud = Boolean.parseBoolean(a[1]);
                            case "cps" -> c.cps = Boolean.parseBoolean(a[1]);
                            case "keystrokes" -> c.keystrokes = Boolean.parseBoolean(a[1]);
                            case "armorStatus" -> c.armorStatus = Boolean.parseBoolean(a[1]);
                            case "effectStatus" -> c.effectStatus = Boolean.parseBoolean(a[1]);
                            case "rgb" -> c.rgb = Boolean.parseBoolean(a[1]);
                            case "spearSwapDelayTicks" -> c.spearSwapDelayTicks = clamp(Integer.parseInt(a[1]), 0, 20);
                            case "animationSpeed" -> c.animationSpeed = clamp(Float.parseFloat(a[1]), 0f, 3f);
                            case "accentR" -> c.accentR = clamp(Integer.parseInt(a[1]), 0, 255);
                            case "accentG" -> c.accentG = clamp(Integer.parseInt(a[1]), 0, 255);
                            case "accentB" -> c.accentB = clamp(Integer.parseInt(a[1]), 0, 255);
                            case "musicUrl" -> c.musicUrl = a[1];
                        }
                    } catch (NumberFormatException badLine) {
                        // Ignore just this one malformed value, keep the default for it.
                    }
                }
            }
        } catch (Exception e) {
            // Unreadable/corrupted file: fall back to a fresh default config
            // instead of letting mod init fail.
            return new ClientConfig();
        }
        return c;
    }

    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    private static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }

    public void save() {
        try {
            Path dir = FILE.getParent();
            if (dir != null) Files.createDirectories(dir);
            String s = "spearSwap="+spearSwap+"\n" +
                    "spearAutoMace="+spearAutoMace+"\n" +
                    "elytraAutoArmor="+elytraAutoArmor+"\n" +
                    "autoSprint="+autoSprint+"\n" +
                    "hud="+hud+"\n" + "cps="+cps+"\n" +
                    "keystrokes="+keystrokes+"\n" +
                    "armorStatus="+armorStatus+"\n" +
                    "effectStatus="+effectStatus+"\n" +
                    "rgb="+rgb+"\n" +
                    "spearSwapDelayTicks="+spearSwapDelayTicks+"\n" +
                    "animationSpeed="+animationSpeed+"\n" +
                    "accentR="+accentR+"\n" + "accentG="+accentG+"\n" + "accentB="+accentB+"\n" +
                    "musicUrl="+musicUrl+"\n";
            // Write to a temp file then atomically move it into place, so a crash
            // or power loss mid-write can't leave behind a truncated/corrupt config.
            Path tmp = FILE.resolveSibling(FILE.getFileName() + ".tmp");
            Files.writeString(tmp, s);
            try {
                Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException notSupported) {
                Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ignored) {}
    }
}

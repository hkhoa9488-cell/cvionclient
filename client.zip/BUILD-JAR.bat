@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ========================================
echo PVPClient - REAL FABRIC 1.21.11 BUILD
echo ========================================

echo [INFO] Searching for JDK 21...
set "JAVA_HOME="

rem 1) Existing JAVA_HOME, but only accept Java 21
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" (
  for /f "tokens=3" %%V in ('"%JAVA_HOME%\bin\java.exe" -version 2^>^&1 ^| findstr /i "version"') do set "CHECKVER=%%V"
  set "CHECKVER=!CHECKVER:\"=!"
  if "!CHECKVER:~0,2!"=="21" echo [INFO] Using JAVA_HOME: %JAVA_HOME%& goto :java_ok
)

rem 2) Search PATH entries without executing an unquoted C:\Program path
for /f "delims=" %%J in ('where java 2^>nul') do (
  set "CAND=%%~dpJ.."
  if exist "!CAND!\bin\java.exe" (
    for /f "tokens=3" %%V in ('"!CAND!\bin\java.exe" -version 2^>^&1 ^| findstr /i "version"') do set "V=%%V"
    set "V=!V:\"=!"
    if "!V:~0,2!"=="21" set "JAVA_HOME=!CAND!"& goto :java_ok
  )
)

rem 3) Common Windows JDK 21 locations
for %%D in (
 "%ProgramFiles%\Java\jdk-21"
 "%ProgramFiles%\Eclipse Adoptium"
 "%ProgramFiles%\Zulu"
 "%ProgramFiles%\Microsoft\jdk-21"
 "%LocalAppData%\Programs\Eclipse Adoptium"
) do (
  if exist "%%~D" (
    for /d %%K in ("%%~D\jdk-21*" "%%~D\zulu21*") do if exist "%%~fK\bin\java.exe" (
      for /f "tokens=3" %%V in ('"%%~fK\bin\java.exe" -version 2^>^&1 ^| findstr /i "version"') do set "V=%%V"
      set "V=!V:\"=!"
      if "!V:~0,2!"=="21" set "JAVA_HOME=%%~fK"& goto :java_ok
    )
  )
)

rem 4) If no Java 21 exists, download a private Temurin JDK 21
set "BOOT=%TEMP%\pvpclient-jdk21"
if exist "%BOOT%\bin\java.exe" (
  set "JAVA_HOME=%BOOT%"
  goto :java_ok
)

echo [INFO] JDK 21 not found. Downloading private Temurin JDK 21...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jdk/hotspot/normal/eclipse'; $o=Join-Path $env:TEMP 'pvpclient-jdk21.zip'; Invoke-WebRequest -UseBasicParsing $u -OutFile $o; Expand-Archive -Force $o (Join-Path $env:TEMP 'pvpclient-jdk21-extract'); $d=Get-ChildItem (Join-Path $env:TEMP 'pvpclient-jdk21-extract') -Directory | Select-Object -First 1; if(Test-Path $d.FullName){if(Test-Path $env:TEMP\pvpclient-jdk21){Remove-Item $env:TEMP\pvpclient-jdk21 -Recurse -Force}; Move-Item $d.FullName $env:TEMP\pvpclient-jdk21}; Remove-Item $o -Force"
if errorlevel 1 goto :java_fail
if not exist "%BOOT%\bin\java.exe" goto :java_fail
set "JAVA_HOME=%BOOT%"

:java_ok
set "PATH=%JAVA_HOME%\bin;%PATH%"
echo [INFO] Using Java:
"%JAVA_HOME%\bin\java.exe" -version

if not exist "%~dp0gradle-8.14.3-bin.zip" (
  echo [INFO] Downloading Gradle 8.14.3...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-8.14.3-bin.zip' -OutFile '%~dp0gradle-8.14.3-bin.zip'"
  if errorlevel 1 goto :fail
)

if not exist "%~dp0gradle-8.14.3\bin\gradle.bat" (
  echo [INFO] Extracting Gradle 8.14.3...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%~dp0gradle-8.14.3-bin.zip' '%~dp0'"
  if errorlevel 1 goto :fail
)

rmdir /s /q "%~dp0build" 2>nul
call "%~dp0gradle-8.14.3\bin\gradle.bat" --no-daemon --stacktrace clean build
if errorlevel 1 goto :fail

set "JARFOUND="
for /f "delims=" %%F in ('dir /b "%~dp0build\libs\*.jar" 2^>nul') do set "JARFOUND=%%F"
if not defined JARFOUND goto :fail

echo.
echo ========================================
echo BUILD SUCCESS
echo ========================================
echo JAR: !JARFOUND!
explorer "%~dp0build\libs"
exit /b 0

:java_fail
echo [ERROR] Could not find or download a usable JDK 21.
echo Install JDK 21 and run BUILD-JAR.bat again.
pause
exit /b 1

:fail
echo.
echo ========================================
echo BUILD FAILED
echo ========================================
echo No valid JAR was reported.
pause
exit /b 1

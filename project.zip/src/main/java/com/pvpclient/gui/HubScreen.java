package com.pvpclient.gui;

import com.pvpclient.PvpClient;
import com.pvpclient.music.MusicManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class HubScreen extends Screen {
    private int tab = 0;
    private EditBox musicUrl;

    public HubScreen() { super(Component.literal("PVP Client")); }

    @Override
    protected void init() {
        int cx = width / 2;
        addRenderableWidget(Button.builder(Component.literal("⚔ Combat"), b -> tab = 0).bounds(cx - 260, 24, 130, 26).build());
        addRenderableWidget(Button.builder(Component.literal("⚡ Movement"), b -> tab = 1).bounds(cx - 125, 24, 130, 26).build());
        addRenderableWidget(Button.builder(Component.literal("● Profile"), b -> tab = 2).bounds(cx + 10, 24, 130, 26).build());
        addRenderableWidget(Button.builder(Component.literal("Music"), b -> tab = 3).bounds(cx + 145, 24, 100, 26).build());

        if (tab == 0) initCombat(cx);
        else if (tab == 1) initMovement(cx);
        else if (tab == 2) initProfile(cx);
        else initMusic(cx);
    }

    private void initCombat(int cx) {
        addRenderableWidget(Button.builder(Component.literal(toggle("Spear Swap", PvpClient.CONFIG.spearSwap)), b -> {
            PvpClient.CONFIG.spearSwap = !PvpClient.CONFIG.spearSwap; b.setMessage(Component.literal(toggleText("Spear Swap", PvpClient.CONFIG.spearSwap))); PvpClient.saveConfig();
        }).bounds(cx - 330, 90, 300, 30).build());
        addRenderableWidget(Button.builder(Component.literal(toggle("Auto Mace after Lunge", PvpClient.CONFIG.spearAutoMace)), b -> {
            PvpClient.CONFIG.spearAutoMace = !PvpClient.CONFIG.spearAutoMace; b.setMessage(Component.literal(toggleText("Auto Mace after Lunge", PvpClient.CONFIG.spearAutoMace))); PvpClient.saveConfig();
        }).bounds(cx - 330, 128, 300, 30).build());
        addRenderableWidget(Button.builder(Component.literal(toggle("Elytra Auto Armor", PvpClient.CONFIG.elytraAutoArmor)), b -> {
            PvpClient.CONFIG.elytraAutoArmor = !PvpClient.CONFIG.elytraAutoArmor; b.setMessage(Component.literal(toggleText("Elytra Auto Armor", PvpClient.CONFIG.elytraAutoArmor))); PvpClient.saveConfig();
        }).bounds(cx + 30, 90, 300, 30).build());
    }

    private void initMovement(int cx) {
        addRenderableWidget(Button.builder(Component.literal(toggle("Auto Sprint", PvpClient.CONFIG.autoSprint)), b -> {
            PvpClient.CONFIG.autoSprint = !PvpClient.CONFIG.autoSprint; b.setMessage(Component.literal(toggleText("Auto Sprint", PvpClient.CONFIG.autoSprint))); PvpClient.saveConfig();
        }).bounds(cx - 150, 100, 300, 32).build());
    }

    private void initProfile(int cx) {
        addRenderableWidget(Button.builder(Component.literal(toggle("HUD", PvpClient.CONFIG.hud)), b -> { PvpClient.CONFIG.hud = !PvpClient.CONFIG.hud; b.setMessage(Component.literal(toggleText("HUD", PvpClient.CONFIG.hud))); PvpClient.saveConfig(); }).bounds(cx - 330, 82, 150, 28).build());
        addRenderableWidget(Button.builder(Component.literal(toggle("CPS", PvpClient.CONFIG.cps)), b -> { PvpClient.CONFIG.cps = !PvpClient.CONFIG.cps; b.setMessage(Component.literal(toggleText("CPS", PvpClient.CONFIG.cps))); PvpClient.saveConfig(); }).bounds(cx - 170, 82, 150, 28).build());
        addRenderableWidget(Button.builder(Component.literal(toggle("Keystrokes", PvpClient.CONFIG.keystrokes)), b -> { PvpClient.CONFIG.keystrokes = !PvpClient.CONFIG.keystrokes; b.setMessage(Component.literal(toggleText("Keystrokes", PvpClient.CONFIG.keystrokes))); PvpClient.saveConfig(); }).bounds(cx - 10, 82, 150, 28).build());
        addRenderableWidget(Button.builder(Component.literal(toggle("Armor Status", PvpClient.CONFIG.armorStatus)), b -> { PvpClient.CONFIG.armorStatus = !PvpClient.CONFIG.armorStatus; b.setMessage(Component.literal(toggleText("Armor Status", PvpClient.CONFIG.armorStatus))); PvpClient.saveConfig(); }).bounds(cx + 150, 82, 150, 28).build());
        addRenderableWidget(Button.builder(Component.literal(toggle("Effects", PvpClient.CONFIG.effectStatus)), b -> { PvpClient.CONFIG.effectStatus = !PvpClient.CONFIG.effectStatus; b.setMessage(Component.literal(toggleText("Effects", PvpClient.CONFIG.effectStatus))); PvpClient.saveConfig(); }).bounds(cx - 330, 118, 150, 28).build());
        addRenderableWidget(Button.builder(Component.literal(toggle("RGB", PvpClient.CONFIG.rgb)), b -> { PvpClient.CONFIG.rgb = !PvpClient.CONFIG.rgb; b.setMessage(Component.literal(toggleText("RGB", PvpClient.CONFIG.rgb))); PvpClient.saveConfig(); }).bounds(cx - 170, 118, 150, 28).build());
        addRenderableWidget(Button.builder(Component.literal("Accent Color"), b -> { PvpClient.CONFIG.accentR = (PvpClient.CONFIG.accentR + 55) % 256; PvpClient.CONFIG.accentG = (PvpClient.CONFIG.accentG + 23) % 256; PvpClient.CONFIG.accentB = (PvpClient.CONFIG.accentB + 71) % 256; PvpClient.saveConfig(); }).bounds(cx - 10, 118, 150, 28).build());
        addRenderableWidget(Button.builder(Component.literal("Animation +"), b -> { PvpClient.CONFIG.animationSpeed = Math.min(3f, PvpClient.CONFIG.animationSpeed + .25f); PvpClient.saveConfig(); }).bounds(cx + 150, 118, 150, 28).build());
    }

    private void initMusic(int cx) {
        musicUrl = new EditBox(font, cx - 220, 95, 440, 24, Component.literal("Audio URL"));
        musicUrl.setValue(PvpClient.CONFIG.musicUrl == null ? "" : PvpClient.CONFIG.musicUrl);
        addRenderableWidget(musicUrl);
        addRenderableWidget(Button.builder(Component.literal("Play"), b -> { PvpClient.CONFIG.musicUrl = musicUrl.getValue(); PvpClient.saveConfig(); MusicManager.playUrl(PvpClient.CONFIG.musicUrl); }).bounds(cx - 150, 132, 90, 28).build());
        addRenderableWidget(Button.builder(Component.literal("Stop"), b -> MusicManager.stop()).bounds(cx - 45, 132, 90, 28).build());
        addRenderableWidget(Button.builder(Component.literal("Save URL"), b -> { PvpClient.CONFIG.musicUrl = musicUrl.getValue(); PvpClient.saveConfig(); }).bounds(cx + 60, 132, 90, 28).build());
    }

    private String toggle(String n, boolean enabled) { return n + "  [" + (enabled ? "ON" : "OFF") + "]"; }
    private String toggleText(String n, boolean enabled) { return toggle(n, enabled); }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int c = rgbColor();
        int x = width / 2 - 360, y = 60, w = 720, h = 250;
        g.fill(x, y, x + w, y + h, 0xD0080914);
        g.fill(x, y, x + w, y + 3, c);
        g.drawString(font, "PVP CLIENT", x + 20, y + 18, 0xFFFFFFFF);
        g.drawString(font, tab == 0 ? "Combat modules" : tab == 1 ? "Movement modules" : tab == 2 ? "Profile / HUD" : "Music Player", x + 20, y + 36, c);
        super.render(g, mouseX, mouseY, delta);
    }

    private int rgbColor() {
        if (!PvpClient.CONFIG.rgb) return (PvpClient.CONFIG.accentR << 16) | (PvpClient.CONFIG.accentG << 8) | PvpClient.CONFIG.accentB;
        double t = (System.currentTimeMillis() % 5000L) / 5000.0;
        int r = (int)(128 + 127 * Math.sin(t * Math.PI * 2));
        int gr = (int)(128 + 127 * Math.sin(t * Math.PI * 2 + 2.094));
        int b = (int)(128 + 127 * Math.sin(t * Math.PI * 2 + 4.188));
        return (r << 16) | (gr << 8) | b;
    }

    @Override public boolean isPauseScreen() { return false; }
}

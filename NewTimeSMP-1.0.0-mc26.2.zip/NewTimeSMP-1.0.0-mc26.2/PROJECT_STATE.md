# PROJECT_STATE (L0 Live State — Token Budget: <500 tokens)
- **Software**: NewTimeSMP `1.0.0` (`NT-1.0.0`)
- **Minecraft Target**: `26.2`
- **Upstream**: `PaperMC/Paper` (`branch: ver/26.2`, `commit: PENDING_GIT_AUDIT` -> run `./scripts/verify-upstream.sh`)
- **Toolchain**: Java 21+ / Gradle Kotlin DSL (inherits Paper upstream wrapper)
- **Current Phase**: `NT-1.0.0` Release Architecture & Core Modules Ready
- **Build & Verification Status**:
  - Core/Observability/Hardware/Diagnostics/Performance/Experimental modules: `IMPLEMENTED_IN_REPO`
  - Upstream Paper Clean Checkout & Patch Apply: `PENDING_LOCAL_GIT_CLONE` (see `scripts/verify-upstream.sh`)
  - Plugin Compatibility Matrix: `FRAMEWORK_READY_UNTESTED_ON_LIVE_PLUGINS`
  - Benchmarks (20/50/100/150/200p): `HARNESS_READY_BASELINE_REQUIRED`
- **Active Guardrails**:
  1. Never claim 100/200p or 20 TPS guarantees without environment-pinned benchmark evidence.
  2. Never enable `newtimesmp-experimental` region scheduler in production (`enabled: false`).
  3. Never mutate world/entity/chunk off owning thread.
- **Next Single Action**: Run `./scripts/verify-upstream.sh` to clone/pin Paper `26.2`, apply `patches/`, and execute `./scripts/build.sh`.

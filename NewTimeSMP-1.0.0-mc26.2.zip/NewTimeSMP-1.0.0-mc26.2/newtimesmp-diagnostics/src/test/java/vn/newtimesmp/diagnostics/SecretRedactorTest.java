package vn.newtimesmp.diagnostics;

import org.junit.jupiter.api.Test;
import vn.newtimesmp.diagnostics.redaction.SecretRedactor;

import static org.assertj.core.api.Assertions.assertThat;

class SecretRedactorTest {

    @Test
    void redactsIpsTokensAndPasswords() {
        String raw = "Player connected from 192.168.1.42:25565 with forwarding-secret=superSecret123 and Bearer abc.def.ghi";
        String redacted = SecretRedactor.redact(raw);
        assertThat(redacted).doesNotContain("192.168.1.42");
        assertThat(redacted).doesNotContain("superSecret123");
        assertThat(redacted).doesNotContain("abc.def.ghi");
        assertThat(redacted).contains("[REDACTED_IP]");
        assertThat(redacted).contains("forwarding-secret=[REDACTED]");
    }
}

package vn.newtimesmp.diagnostics.redaction;

import java.util.regex.Pattern;

/**
 * Redacts IPv4/IPv6 addresses, tokens, passwords, and secrets before exporting diagnostic bundles.
 */
public final class SecretRedactor {
    private static final Pattern IPV4_PATTERN = Pattern.compile("\\b(?:\\d{1,3}\\.){3}\\d{1,3}(?::\\d{1,5})?\\b");
    private static final Pattern SECRET_KV_PATTERN = Pattern.compile(
        "(?i)(password|passwd|secret|token|api[-_]?key|auth[-_]?key|forwarding-secret)\\s*[:=]\\s*[^\\s,;\"']+"
    );
    private static final Pattern BEARER_PATTERN = Pattern.compile("(?i)Bearer\\s+[A-Za-z0-9._\\-]+");

    private SecretRedactor() {}

    public static String redact(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        String out = SECRET_KV_PATTERN.matcher(input).replaceAll("$1=[REDACTED]");
        out = BEARER_PATTERN.matcher(out).replaceAll("Bearer [REDACTED]");
        out = IPV4_PATTERN.matcher(out).replaceAll("[REDACTED_IP]");
        return out;
    }
}

package vn.newtimesmp.diagnostics.report;

import vn.newtimesmp.api.compatibility.PluginCompatibilityRecord;
import vn.newtimesmp.api.featureflags.FeatureFlag;
import vn.newtimesmp.api.hardware.HardwareProfileSnapshot;
import vn.newtimesmp.api.metrics.TickMetricsSnapshot;
import vn.newtimesmp.api.version.NewTimeVersionInfo;
import vn.newtimesmp.diagnostics.redaction.SecretRedactor;

import java.time.Instant;
import java.util.List;
import java.util.Map;

public final class DiagnosticReportGenerator {
    private DiagnosticReportGenerator() {}

    public static String generateMarkdownReport(
        NewTimeVersionInfo version,
        TickMetricsSnapshot metrics,
        HardwareProfileSnapshot hardware,
        Map<FeatureFlag, Boolean> flags,
        List<PluginCompatibilityRecord> compatRecords,
        boolean redactSecrets
    ) {
        StringBuilder sb = new StringBuilder();
        sb.append("# NewTimeSMP Diagnostic Report\n");
        sb.append("- Generated At: ").append(Instant.now()).append("\n");
        sb.append("- Build: ").append(version.displayBanner()).append("\n");
        sb.append("- Hardware Profile: ").append(hardware.selectedTier())
          .append(" (adminOverridden=").append(hardware.adminOverridden()).append(")\n");
        sb.append("- Effective CPUs: ").append(String.format("%.2f", hardware.effectiveCpus()))
          .append(" / Host CPUs: ").append(hardware.hostLogicalCpus()).append("\n");
        sb.append("- JVM: ").append(hardware.jvmVendor()).append(" ").append(hardware.jvmVersion()).append("\n\n");

        sb.append("## Tick & Runtime Metrics\n");
        sb.append(String.format("- TPS (1m/5m/15m): %.2f / %.2f / %.2f%n", metrics.tps1m(), metrics.tps5m(), metrics.tps15m()));
        sb.append(String.format("- MSPT (p50/p95/p99/max): %.2fms / %.2fms / %.2fms / %.2fms%n",
            metrics.msptP50(), metrics.msptP95(), metrics.msptP99(), metrics.msptMax()));
        sb.append("- Ticks > 50ms: ").append(metrics.ticksOver50Ms()).append("\n");
        sb.append(String.format("- Heap Used/Max: %dMB / %dMB (GC Pause Total: %dms)%n",
            metrics.heapUsedBytes() / (1024 * 1024),
            metrics.heapMaxBytes() / (1024 * 1024),
            metrics.gcTotalPauseMs()));
        sb.append("- Chunks: ").append(metrics.loadedChunks())
          .append(" | Entities: ").append(metrics.activeEntities())
          .append(" | QueueDepth: ").append(metrics.executorQueueDepth()).append("\n\n");

        sb.append("## Feature Flags\n");
        flags.forEach((k, v) -> sb.append("- ").append(k.configPath()).append(": ").append(v).append("\n"));

        sb.append("\n## Plugin Compatibility Summary\n");
        if (compatRecords.isEmpty()) {
            sb.append("- No plugins evaluated yet (status: UNTESTED)\n");
        } else {
            for (PluginCompatibilityRecord r : compatRecords) {
                sb.append("- ").append(r.pluginName()).append(" ").append(r.pluginVersion())
                  .append(" -> ").append(r.status()).append(" (").append(r.notes()).append(")\n");
            }
        }

        String raw = sb.toString();
        return redactSecrets ? SecretRedactor.redact(raw) : raw;
    }
}

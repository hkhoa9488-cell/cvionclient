package vn.newtimesmp.diagnostics.command;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vn.newtimesmp.api.NewTimeServer;
import vn.newtimesmp.api.featureflags.FeatureFlag;
import vn.newtimesmp.api.hardware.HardwareProfileSnapshot;
import vn.newtimesmp.api.metrics.TickMetricsSnapshot;
import vn.newtimesmp.core.config.ConfigManager;
import vn.newtimesmp.core.featureflags.FeatureFlagRegistry;
import vn.newtimesmp.diagnostics.report.DiagnosticReportGenerator;

import java.io.IOException;
import java.util.function.Predicate;

/**
 * Handles /newtimesmp <version|status|diagnostics|performance|hardware|profile|reload>
 * enforcing permission checks and structured audit logs on state changes.
 */
public final class NewTimeCommandHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(NewTimeCommandHandler.class);

    private final NewTimeServer server;
    private final ConfigManager configManager;
    private final FeatureFlagRegistry flagRegistry;

    public NewTimeCommandHandler(NewTimeServer server, ConfigManager configManager, FeatureFlagRegistry flagRegistry) {
        this.server = server;
        this.configManager = configManager;
        this.flagRegistry = flagRegistry;
    }

    public String execute(String senderName, Predicate<String> hasPermission, String[] args) {
        String sub = (args == null || args.length == 0) ? "status" : args[0].toLowerCase();
        String perm = "newtimesmp.command." + sub;
        if (!hasPermission.test(perm)) {
            return "Permission denied: missing " + perm;
        }

        return switch (sub) {
            case "version" -> server.versionInfo().displayBanner();
            case "status" -> {
                TickMetricsSnapshot m = server.metricsSnapshot();
                yield String.format("NewTimeSMP %s (MC %s) | TPS(1m)=%.2f | MSPT p50/p95/p99=%.2f/%.2f/%.2fms | Profile=%s",
                    server.versionInfo().softwareVersion(),
                    server.versionInfo().minecraftVersion(),
                    m.tps1m(), m.msptP50(), m.msptP95(), m.msptP99(),
                    server.hardwareProfile().selectedTier());
            }
            case "performance" -> {
                TickMetricsSnapshot m = server.metricsSnapshot();
                yield String.format("MSPT p50=%.2fms p95=%.2fms p99=%.2fms max=%.2fms | ticks>50ms=%d | queue=%d rejected=%d",
                    m.msptP50(), m.msptP95(), m.msptP99(), m.msptMax(),
                    m.ticksOver50Ms(), m.executorQueueDepth(), m.executorRejectedTasks());
            }
            case "hardware", "profile" -> {
                HardwareProfileSnapshot h = server.hardwareProfile();
                yield String.format("Profile=%s (overridden=%s) | EffectiveCPUs=%.2f/%d | MaxHeap=%dMB | Workers(CPU=%d,IO=%d) | Reasons=%s",
                    h.selectedTier(), h.adminOverridden(), h.effectiveCpus(), h.hostLogicalCpus(),
                    h.jvmMaxHeapBytes() / (1024 * 1024), h.recommendedCpuWorkers(), h.recommendedIoWorkers(),
                    h.selectionReasons());
            }
            case "diagnostics" -> {
                if (!server.isFeatureEnabled(FeatureFlag.DIAGNOSTICS_ENABLED)) {
                    yield "Diagnostics are disabled in newtimesmp.yml.";
                }
                yield DiagnosticReportGenerator.generateMarkdownReport(
                    server.versionInfo(),
                    server.metricsSnapshot(),
                    server.hardwareProfile(),
                    flagRegistry.snapshot(),
                    server.compatibilityReport(),
                    true
                );
            }
            case "reload" -> {
                try {
                    configManager.createBackup("newtimesmp.yml");
                    configManager.loadAndValidate(flagRegistry, true);
                    LOGGER.info("[AUDIT] Admin '{}' reloaded safe-to-reload NewTimeSMP settings.", senderName);
                    yield "NewTimeSMP safe-to-reload settings reloaded (backup created). Restart required for structural/pool changes.";
                } catch (IOException | RuntimeException e) {
                    LOGGER.error("[AUDIT] Admin '{}' reload failed: {}", senderName, e.getMessage());
                    yield "Reload aborted (previous state preserved): " + e.getMessage();
                }
            }
            default -> "Usage: /newtimesmp <version|status|diagnostics|performance|hardware|profile|reload>";
        };
    }
}

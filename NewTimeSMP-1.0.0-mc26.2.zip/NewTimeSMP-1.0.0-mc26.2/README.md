# NewTimeSMP `1.0.0` (Minecraft `26.2`)

**NewTimeSMP** is a Paper-derived Minecraft Java server distribution focused on **correctness, data safety, plugin compatibility, low-overhead observability, hardware-aware conservative profiles, and token-efficient AI-assisted maintenance**.

> **Honest Engineering Policy**: NewTimeSMP `1.0.0` does **not** make blanket promises of "100/200 players on any hardware", "guaranteed 20 TPS", or "100% plugin compatibility". Every optimization and capacity claim is gated by reproducible A/B benchmarks and compatibility reports.

## Module Architecture
- `newtimesmp-api` — Public contracts, immutable metric/hardware snapshots, compatibility enums (zero server internals).
- `newtimesmp-core` — Build metadata (`1.0.0` / MC `26.2`), strict YAML schema validator + backup/migration, feature flags (default `OFF` for risky features), 10-step startup & 8-step shutdown lifecycle.
- `newtimesmp-observability` — Zero-allocation lock-free tick duration histogram (`p50`/`p95`/`p99`), rolling TPS, `ticks > 50ms`, GC/heap, chunk, entity, and network queue counters.
- `newtimesmp-hardware` — Safe Linux cgroup v1/v2 + CPU/RAM/JVM detector and conservative preset selector (`Legacy`, `Standard`, `Performance`, `High Performance`).
- `newtimesmp-diagnostics` — `/newtimesmp` command suite (`version`, `status`, `diagnostics`, `performance`, `hardware`, `profile`, `reload`), passive watchdog, and strict secret/IP redactor.
- `newtimesmp-performance` — Bounded executors with backpressure and capacity-bounded LRU caches.
- `newtimesmp-experimental` — Isolated thread-ownership assertion guards and region scheduler contracts (`enabled: false` by default).

## Quick Start
```bash
# 1. Pin & verify Paper upstream (Minecraft 26.2)
./scripts/verify-upstream.sh

# 2. Run unit, concurrency, and compatibility tests
./gradlew test

# 3. Build NewTimeSMP modules & server bundle
./scripts/build.sh

# 4. Pack minimal token context (~800 tokens) for AI coding sessions
./scripts/context-pack.sh
```

plugins {
    java
}

val newtimesmpVersion: String by project
val minecraftVersion: String by project
val javaTarget: String by project

allprojects {
    group = "vn.newtimesmp"
    version = "$newtimesmpVersion-mc$minecraftVersion"

    repositories {
        mavenCentral()
        maven("https://repo.papermc.io/repository/maven-public/")
    }
}

subprojects {
    apply(plugin = "java-library")

    java {
        toolchain {
            languageVersion.set(JavaLanguageVersion.of(javaTarget.toInt()))
        }
        withSourcesJar()
    }

    tasks.withType<JavaCompile>().configureEach {
        options.encoding = "UTF-8"
        options.release.set(javaTarget.toInt())
    }

    tasks.withType<Test>().configureEach {
        useJUnitPlatform()
        testLogging {
            events("passed", "skipped", "failed")
        }
    }
}

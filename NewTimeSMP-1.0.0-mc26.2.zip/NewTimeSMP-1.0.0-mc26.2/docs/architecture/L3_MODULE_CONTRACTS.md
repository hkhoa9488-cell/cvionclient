# L3 Spec — Module Dependency & Thread Ownership Matrix

| Module | Allowed Dependencies | Thread Ownership Contract |
|---|---|---|
| `newtimesmp-api` | None | Immutable records & thread-safe interfaces only |
| `newtimesmp-core` | `api`, SnakeYAML, SLF4J | Lifecycle/config loaded on main thread; `FeatureFlagRegistry` thread-safe |
| `newtimesmp-observability` | `api`, `core` | `recordTickNanos` called from server tick loop (lock-free); snapshots readable from any thread |
| `newtimesmp-hardware` | `api`, `core` | Read-only startup detection; never mutates gameplay |
| `newtimesmp-performance` | `api`, `core`, `observability` | Bounded pools (`BoundedTaskExecutor`); workers never invoke Bukkit world/entity APIs |
| `newtimesmp-diagnostics` | `api`, `core`, `observability`, `hardware` | Read-only commands thread-safe; `/newtimesmp reload` requires permission + audit log |
| `newtimesmp-experimental` | `api`, `core` | Strictly `enabled: false` by default; dev/test ownership assertions only |

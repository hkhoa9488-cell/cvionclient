# L2 Spec — NewTimeSMP 1.0.0 (Minecraft 26.2)

## Release Gate Checklist
1. Clean checkout + pinned `UPSTREAM.lock` for Paper `26.2`.
2. All unit, concurrency, and redaction tests pass (`gradle test`).
3. World save/load regression verified on Paper `26.2` test world.
4. Plugin compatibility matrix published with explicit `PASS`/`FAIL`/`UNTESTED`/`UNSUPPORTED` labels.
5. No critical data-safety or deadlock blockers.
6. Benchmark report includes hardware, JVM flags, seed, view/simulation distance, and player count.

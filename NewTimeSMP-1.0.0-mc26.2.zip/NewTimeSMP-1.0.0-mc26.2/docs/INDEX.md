# docs/INDEX.md — Tiered Documentation Map (Token-Efficient)

- **L0 (`PROJECT_STATE.md`, `UPSTREAM.lock`)**: Live target (`MC 26.2`), release (`1.0.0`), active task (~450 tokens).
- **L1 (`ROADMAP.md`, `AGENTS.md`)**: Architecture rules & release milestones (~600 tokens).
- **L2 (`docs/architecture/L2_RELEASE_1_0_0_SPEC.md`)**: Detailed `NT-1.0.0` release gate & runtime architecture.
- **L3 (`docs/architecture/L3_MODULE_CONTRACTS.md`)**: Thread-ownership & dependency matrix per module.
- **L4 (Source Code)**: Open only targeted classes in `newtimesmp-*/src/main/java/...`.
- **L5 (`benchmarks/README.md`)**: Reproducible benchmark environment checklist & workload matrix.

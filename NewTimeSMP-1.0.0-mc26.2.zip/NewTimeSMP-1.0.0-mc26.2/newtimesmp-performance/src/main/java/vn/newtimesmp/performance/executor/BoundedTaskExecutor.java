package vn.newtimesmp.performance.executor;

import vn.newtimesmp.observability.export.ServerMetricsCollector;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Bounded worker pool with explicit queue ceiling, backpressure policy, metrics, and graceful drain.
 */
public final class BoundedTaskExecutor implements AutoCloseable {
    private final ThreadPoolExecutor delegate;
    private final ServerMetricsCollector metrics;

    public BoundedTaskExecutor(
        String poolName,
        int workerThreads,
        int queueCapacity,
        boolean callerRunsOnFull,
        ServerMetricsCollector metrics
    ) {
        if (workerThreads < 1 || queueCapacity < 1) {
            throw new IllegalArgumentException("workerThreads and queueCapacity must be >= 1");
        }
        this.metrics = metrics;
        AtomicInteger counter = new AtomicInteger(1);
        ThreadFactory factory = r -> {
            Thread t = new Thread(r, poolName + "-" + counter.getAndIncrement());
            t.setDaemon(true);
            return t;
        };
        RejectedExecutionHandler rejectionHandler = (r, executor) -> {
            if (metrics != null) {
                metrics.recordRejectedTask();
            }
            if (callerRunsOnFull && !executor.isShutdown()) {
                r.run();
            } else {
                throw new RejectedExecutionException("Bounded queue saturated for pool " + poolName);
            }
        };
        this.delegate = new ThreadPoolExecutor(
            workerThreads,
            workerThreads,
            30L,
            TimeUnit.SECONDS,
            new ArrayBlockingQueue<>(queueCapacity),
            factory,
            rejectionHandler
        );
    }

    public void submit(Runnable task) {
        if (metrics != null) {
            metrics.incrementQueueDepth();
        }
        try {
            delegate.execute(() -> {
                try {
                    task.run();
                } finally {
                    if (metrics != null) {
                        metrics.decrementQueueDepth();
                    }
                }
            });
        } catch (RuntimeException ex) {
            if (metrics != null) {
                metrics.decrementQueueDepth();
            }
            throw ex;
        }
    }

    public int queuedTasks() {
        return delegate.getQueue().size();
    }

    @Override
    public void close() {
        delegate.shutdown();
        try {
            if (!delegate.awaitTermination(5, TimeUnit.SECONDS)) {
                delegate.shutdownNow();
            }
        } catch (InterruptedException e) {
            delegate.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}

package vn.newtimesmp.performance.cache;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.LongAdder;

/**
 * Capacity-bounded LRU cache preventing unbounded heap retention.
 */
public final class BoundedLruCache<K, V> {
    private final int maxEntries;
    private final LinkedHashMap<K, V> map;
    private final LongAdder hits = new LongAdder();
    private final LongAdder misses = new LongAdder();
    private final LongAdder evictions = new LongAdder();

    public BoundedLruCache(int maxEntries) {
        if (maxEntries < 1) {
            throw new IllegalArgumentException("maxEntries must be >= 1");
        }
        this.maxEntries = maxEntries;
        this.map = new LinkedHashMap<>(16, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
                boolean shouldEvict = size() > BoundedLruCache.this.maxEntries;
                if (shouldEvict) {
                    evictions.increment();
                }
                return shouldEvict;
            }
        };
    }

    public synchronized Optional<V> get(K key) {
        V val = map.get(key);
        if (val != null) {
            hits.increment();
            return Optional.of(val);
        }
        misses.increment();
        return Optional.empty();
    }

    public synchronized void put(K key, V value) {
        map.put(key, value);
    }

    public synchronized int size() {
        return map.size();
    }

    public long hits() {
        return hits.sum();
    }

    public long misses() {
        return misses.sum();
    }

    public long evictions() {
        return evictions.sum();
    }
}

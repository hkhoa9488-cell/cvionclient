dependencies {
    api(project(":newtimesmp-api"))
    implementation(project(":newtimesmp-core"))
    implementation(libs.slf4j.api)

    testImplementation(libs.junit.jupiter)
    testImplementation(libs.assertj.core)
    testRuntimeOnly(libs.slf4j.simple)
}

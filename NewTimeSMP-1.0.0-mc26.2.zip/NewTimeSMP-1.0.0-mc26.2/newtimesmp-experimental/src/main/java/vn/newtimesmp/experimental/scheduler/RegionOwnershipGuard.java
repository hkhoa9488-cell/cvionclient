package vn.newtimesmp.experimental.scheduler;

import vn.newtimesmp.api.featureflags.FeatureFlag;
import vn.newtimesmp.core.featureflags.FeatureFlagRegistry;

/**
 * Isolated research guard verifying thread ownership contracts before any world/chunk mutation.
 * Disabled by default in production (experimental.region-scheduler.enabled = false).
 */
public final class RegionOwnershipGuard {
    private final FeatureFlagRegistry flags;

    public RegionOwnershipGuard(FeatureFlagRegistry flags) {
        this.flags = flags;
    }

    public void assertOwningThread(Thread expectedOwner, String operation) {
        if (!flags.isEnabled(FeatureFlag.EXPERIMENTAL_REGION_SCHEDULER)) {
            return;
        }
        Thread current = Thread.currentThread();
        if (expectedOwner != null && current != expectedOwner) {
            throw new IllegalStateException(
                "Cross-thread ownership violation during '" + operation + "': expected="
                    + expectedOwner.getName() + ", actual=" + current.getName()
            );
        }
    }
}

rootProject.name = "NewTimeSMP"

include(
    "newtimesmp-api",
    "newtimesmp-core",
    "newtimesmp-observability",
    "newtimesmp-hardware",
    "newtimesmp-diagnostics",
    "newtimesmp-performance",
    "newtimesmp-experimental"
)

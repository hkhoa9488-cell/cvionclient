# TASK.md — Active Execution Slice

- **Task ID**: `NT-1.0.0-BOOTSTRAP-01`
- **Goal**: Verify local Paper upstream `26.2` checkout, pin commit SHA in `UPSTREAM.lock`, and run full module test suite.
- **Non-Goals**: Do NOT enable `experimental.region-scheduler`; do NOT add unbenchmarked gameplay patches.
- **Allowed Scope**: `UPSTREAM.lock`, `PROJECT_STATE.md`, `scripts/verify-upstream.sh`, `benchmarks/baselines/`.
- **Invariants**: Zero gameplay changes; zero main-thread blocking metrics; all risky flags default `OFF`.
- **Acceptance Criteria**:
  1. `UPSTREAM.lock` contains verified Paper `26.2` SHA.
  2. `./gradlew test` passes 100% across all `newtimesmp-*` modules.
  3. Baseline idle/SMP benchmark recorded in `benchmarks/baselines/`.
- **Rollback Plan**: `git checkout -- UPSTREAM.lock PROJECT_STATE.md` or revert patch commit.

package vn.newtimesmp.api.hardware;

public enum HardwareTier {
    LEGACY("legacy"),
    STANDARD("standard"),
    PERFORMANCE("performance"),
    HIGH_PERFORMANCE("high-performance");

    private final String configKey;

    HardwareTier(String configKey) {
        this.configKey = configKey;
    }

    public String configKey() {
        return configKey;
    }
}

package vn.newtimesmp.api;

import vn.newtimesmp.api.compatibility.PluginCompatibilityRecord;
import vn.newtimesmp.api.featureflags.FeatureFlag;
import vn.newtimesmp.api.hardware.HardwareProfileSnapshot;
import vn.newtimesmp.api.metrics.TickMetricsSnapshot;
import vn.newtimesmp.api.version.NewTimeVersionInfo;

import java.util.List;

public interface NewTimeServer {
    NewTimeVersionInfo versionInfo();
    TickMetricsSnapshot metricsSnapshot();
    HardwareProfileSnapshot hardwareProfile();
    boolean isFeatureEnabled(FeatureFlag flag);
    List<PluginCompatibilityRecord> compatibilityReport();
}

package vn.newtimesmp.api.version;

public record NewTimeVersionInfo(
    String softwareName,
    String softwareVersion,
    String minecraftVersion,
    String releaseTag,
    String upstreamName,
    String upstreamCommit
) {
    public String displayBanner() {
        return softwareName + " v" + softwareVersion + " (" + releaseTag + ") for Minecraft " + minecraftVersion
            + " [upstream=" + upstreamName + "@" + upstreamCommit + "]";
    }
}

package vn.newtimesmp.api.featureflags;

public enum FeatureFlag {
    DIAGNOSTICS_ENABLED("diagnostics.enabled", true, true),
    OBSERVABILITY_COLLECTOR("observability.collector", true, true),
    HARDWARE_AUTO_PROFILE("performance.auto-detect", true, false),
    BOUNDED_EXECUTORS("performance.bounded-executors", true, false),
    EXPERIMENTAL_REGION_SCHEDULER("experimental.region-scheduler.enabled", false, false),
    EXPERIMENTAL_ASYNC_TASKS("experimental.async-experiments.enabled", false, false),
    EXPERIMENTAL_ADAPTIVE_TUNING("experimental.adaptive-tuning.enabled", false, false);

    private final String configPath;
    private final boolean defaultEnabled;
    private final boolean safeToReload;

    FeatureFlag(String configPath, boolean defaultEnabled, boolean safeToReload) {
        this.configPath = configPath;
        this.defaultEnabled = defaultEnabled;
        this.safeToReload = safeToReload;
    }

    public String configPath() {
        return configPath;
    }

    public boolean defaultEnabled() {
        return defaultEnabled;
    }

    public boolean safeToReload() {
        return safeToReload;
    }
}

package vn.newtimesmp.api.hardware;

import java.util.List;

public record HardwareProfileSnapshot(
    HardwareTier selectedTier,
    boolean adminOverridden,
    int hostLogicalCpus,
    double effectiveCpus,
    long jvmMaxHeapBytes,
    long containerMemoryLimitBytes,
    String jvmVendor,
    String jvmVersion,
    String osArch,
    int recommendedCpuWorkers,
    int recommendedIoWorkers,
    List<String> selectionReasons
) {}

package vn.newtimesmp.api.compatibility;

public enum CompatibilityStatus {
    PASS,
    FAIL,
    UNTESTED,
    UNSUPPORTED
}

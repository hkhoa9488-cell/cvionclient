package vn.newtimesmp.api.metrics;

public record TickMetricsSnapshot(
    long sampleCount,
    double tps1m,
    double tps5m,
    double tps15m,
    double msptP50,
    double msptP95,
    double msptP99,
    double msptMax,
    long ticksOver50Ms,
    long heapUsedBytes,
    long heapCommittedBytes,
    long heapMaxBytes,
    long gcTotalPauseMs,
    int loadedChunks,
    int activeEntities,
    long executorQueueDepth,
    long executorRejectedTasks
) {}

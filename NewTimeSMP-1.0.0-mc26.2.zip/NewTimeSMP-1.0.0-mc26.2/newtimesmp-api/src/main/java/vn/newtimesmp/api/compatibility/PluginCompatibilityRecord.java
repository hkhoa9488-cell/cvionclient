package vn.newtimesmp.api.compatibility;

public record PluginCompatibilityRecord(
    String pluginName,
    String pluginVersion,
    String serverBuild,
    CompatibilityStatus status,
    String notes
) {}

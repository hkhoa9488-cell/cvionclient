dependencies {
    testImplementation(libs.junit.jupiter)
    testImplementation(libs.assertj.core)
}

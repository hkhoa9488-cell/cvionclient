package vn.newtimesmp.observability.tick;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;

/**
 * Fixed-capacity ring buffer recording tick durations in nanoseconds without blocking the main thread.
 */
public final class LockFreeTickHistogram {
    private final long[] ringNanos;
    private final int capacity;
    private final AtomicLong writeIndex = new AtomicLong(0);
    private final LongAdder ticksOver50Ms = new LongAdder();

    public LockFreeTickHistogram(int capacity) {
        if (capacity < 20) {
            throw new IllegalArgumentException("Histogram capacity must be >= 20 ticks");
        }
        this.capacity = capacity;
        this.ringNanos = new long[capacity];
    }

    public void recordTickNanos(long durationNanos) {
        long clamped = Math.max(0L, durationNanos);
        long idx = writeIndex.getAndIncrement();
        ringNanos[(int) (idx % capacity)] = clamped;
        if (clamped > 50_000_000L) {
            ticksOver50Ms.increment();
        }
    }

    public TickPercentiles snapshot() {
        long total = writeIndex.get();
        int count = (int) Math.min(total, capacity);
        if (count == 0) {
            return new TickPercentiles(0, 20.0, 20.0, 20.0, 0.0, 0.0, 0.0, 0.0, 0L);
        }

        long[] copy = new long[count];
        for (int i = 0; i < count; i++) {
            long seq = total - count + i;
            copy[i] = ringNanos[(int) (seq % capacity)];
        }
        Arrays.sort(copy);

        double p50Ms = nanosToMs(copy[(int) Math.floor(0.50 * (count - 1))]);
        double p95Ms = nanosToMs(copy[(int) Math.floor(0.95 * (count - 1))]);
        double p99Ms = nanosToMs(copy[(int) Math.floor(0.99 * (count - 1))]);
        double maxMs = nanosToMs(copy[count - 1]);

        double tps1m = computeRollingTps(total, Math.min(count, 1200));
        double tps5m = computeRollingTps(total, Math.min(count, 6000));
        double tps15m = computeRollingTps(total, Math.min(count, 18000));

        return new TickPercentiles(
            total,
            tps1m,
            tps5m,
            tps15m,
            p50Ms,
            p95Ms,
            p99Ms,
            maxMs,
            ticksOver50Ms.sum()
        );
    }

    private double computeRollingTps(long totalWritten, int windowSamples) {
        if (windowSamples <= 0) {
            return 20.0;
        }
        long sumNanos = 0L;
        for (int i = 0; i < windowSamples; i++) {
            long seq = totalWritten - windowSamples + i;
            long tickNanos = Math.max(50_000_000L, ringNanos[(int) (seq % capacity)]);
            sumNanos += tickNanos;
        }
        double elapsedSeconds = sumNanos / 1_000_000_000.0;
        return Math.min(20.0, windowSamples / elapsedSeconds);
    }

    private static double nanosToMs(long nanos) {
        return nanos / 1_000_000.0;
    }

    public record TickPercentiles(
        long sampleCount,
        double tps1m,
        double tps5m,
        double tps15m,
        double p50Ms,
        double p95Ms,
        double p99Ms,
        double maxMs,
        long ticksOver50Ms
    ) {}
}

package vn.newtimesmp.observability.export;

import vn.newtimesmp.api.metrics.TickMetricsSnapshot;
import vn.newtimesmp.observability.tick.LockFreeTickHistogram;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryUsage;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAdder;

public final class ServerMetricsCollector {
    private final LockFreeTickHistogram histogram;
    private final AtomicInteger loadedChunks = new AtomicInteger(0);
    private final AtomicInteger activeEntities = new AtomicInteger(0);
    private final LongAdder executorQueueDepth = new LongAdder();
    private final LongAdder executorRejectedTasks = new LongAdder();

    public ServerMetricsCollector(int histogramCapacity) {
        this.histogram = new LockFreeTickHistogram(histogramCapacity);
    }

    public void recordTickNanos(long durationNanos) {
        histogram.recordTickNanos(durationNanos);
    }

    public void updateWorldCounts(int chunks, int entities) {
        loadedChunks.set(chunks);
        activeEntities.set(entities);
    }

    public void incrementQueueDepth() {
        executorQueueDepth.increment();
    }

    public void decrementQueueDepth() {
        executorQueueDepth.decrement();
    }

    public void recordRejectedTask() {
        executorRejectedTasks.increment();
    }

    public TickMetricsSnapshot buildSnapshot() {
        LockFreeTickHistogram.TickPercentiles tp = histogram.snapshot();
        MemoryUsage heap = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
        long gcPauseMs = 0L;
        for (GarbageCollectorMXBean gc : ManagementFactory.getGarbageCollectorMXBeans()) {
            long t = gc.getCollectionTime();
            if (t > 0) {
                gcPauseMs += t;
            }
        }
        return new TickMetricsSnapshot(
            tp.sampleCount(),
            tp.tps1m(),
            tp.tps5m(),
            tp.tps15m(),
            tp.p50Ms(),
            tp.p95Ms(),
            tp.p99Ms(),
            tp.maxMs(),
            tp.ticksOver50Ms(),
            heap.getUsed(),
            heap.getCommitted(),
            heap.getMax(),
            gcPauseMs,
            loadedChunks.get(),
            activeEntities.get(),
            Math.max(0L, executorQueueDepth.sum()),
            executorRejectedTasks.sum()
        );
    }
}

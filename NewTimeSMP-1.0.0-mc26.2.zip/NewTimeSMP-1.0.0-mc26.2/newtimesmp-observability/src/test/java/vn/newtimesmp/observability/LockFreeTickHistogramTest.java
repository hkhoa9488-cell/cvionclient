package vn.newtimesmp.observability;

import org.junit.jupiter.api.Test;
import vn.newtimesmp.observability.tick.LockFreeTickHistogram;

import static org.assertj.core.api.Assertions.assertThat;

class LockFreeTickHistogramTest {

    @Test
    void computesPercentilesAndSlowTicksAccurately() {
        LockFreeTickHistogram hist = new LockFreeTickHistogram(100);
        for (int i = 1; i <= 100; i++) {
            hist.recordTickNanos(i * 1_000_000L); // 1ms .. 100ms
        }
        var snap = hist.snapshot();
        assertThat(snap.sampleCount()).isEqualTo(100);
        assertThat(snap.p50Ms()).isEqualTo(50.0);
        assertThat(snap.p95Ms()).isEqualTo(95.0);
        assertThat(snap.p99Ms()).isEqualTo(99.0);
        assertThat(snap.ticksOver50Ms()).isEqualTo(50L);
    }
}

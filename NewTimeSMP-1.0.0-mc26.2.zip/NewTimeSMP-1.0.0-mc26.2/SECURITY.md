# Security & Diagnostic Redaction Policy

1. **Secret Redaction**: `SecretRedactor` automatically masks IPv4/IPv6 addresses, Bearer tokens, passwords, secret keys, and session tokens in all `/newtimesmp diagnostics` outputs.
2. **Permission & Audit**: State-mutating commands (`/newtimesmp reload`) require `newtimesmp.command.reload` and emit structured audit logs.
3. **Reporting Vulnerabilities**: Do not open public issues for exploitable server crashes, dupes, or permission bypasses. Report privately with reproduction steps and `UPSTREAM.lock` commit details.

package vn.newtimesmp.core;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import vn.newtimesmp.api.featureflags.FeatureFlag;
import vn.newtimesmp.core.config.ConfigManager;
import vn.newtimesmp.core.config.ConfigValidationException;
import vn.newtimesmp.core.featureflags.FeatureFlagRegistry;
import vn.newtimesmp.core.lifecycle.LifecyclePhase;
import vn.newtimesmp.core.lifecycle.NewTimeLifecycleManager;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ConfigAndLifecycleTest {

    @Test
    void startupAndShutdownFollowOrderedLifecycle(@TempDir Path tempDir) throws Exception {
        ConfigManager cm = new ConfigManager(tempDir);
        FeatureFlagRegistry flags = new FeatureFlagRegistry();
        NewTimeLifecycleManager lifecycle = new NewTimeLifecycleManager(cm, flags);

        assertThat(lifecycle.phase()).isEqualTo(LifecyclePhase.UNINITIALIZED);
        var bundle = lifecycle.startup(() -> {}, () -> {}, () -> {});
        assertThat(lifecycle.phase()).isEqualTo(LifecyclePhase.READY);
        assertThat(bundle.schemaVersion()).isEqualTo(1);
        assertThat(flags.isEnabled(FeatureFlag.EXPERIMENTAL_REGION_SCHEDULER)).isFalse();

        lifecycle.shutdown();
        assertThat(lifecycle.phase()).isEqualTo(LifecyclePhase.STOPPED);
    }

    @Test
    void invalidConfigFailsFastWithClearPath(@TempDir Path tempDir) throws Exception {
        Files.writeString(tempDir.resolve("newtimesmp.yml"), "settings:\n  version: 999\n");
        ConfigManager cm = new ConfigManager(tempDir);
        FeatureFlagRegistry flags = new FeatureFlagRegistry();

        assertThatThrownBy(() -> cm.loadAndValidate(flags, false))
            .isInstanceOf(ConfigValidationException.class)
            .hasMessageContaining("newtimesmp.yml -> settings.version");
    }
}

package vn.newtimesmp.core.version;

import vn.newtimesmp.api.version.NewTimeVersionInfo;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class BuildMetadata {
    private BuildMetadata() {}

    public static NewTimeVersionInfo load() {
        Properties props = new Properties();
        try (InputStream in = BuildMetadata.class.getClassLoader().getResourceAsStream("newtimesmp-build.properties")) {
            if (in != null) {
                props.load(in);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Failed to read newtimesmp-build.properties", e);
        }
        return new NewTimeVersionInfo(
            props.getProperty("software.name", "NewTimeSMP"),
            props.getProperty("software.version", "1.0.0"),
            props.getProperty("minecraft.version", "26.2"),
            props.getProperty("release.tag", "NT-1.0.0"),
            props.getProperty("upstream.name", "Paper"),
            props.getProperty("upstream.commit", "PENDING_GIT_AUDIT")
        );
    }
}

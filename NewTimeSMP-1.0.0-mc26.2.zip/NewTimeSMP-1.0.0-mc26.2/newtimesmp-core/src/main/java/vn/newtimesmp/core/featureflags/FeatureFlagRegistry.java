package vn.newtimesmp.core.featureflags;

import vn.newtimesmp.api.featureflags.FeatureFlag;

import java.util.EnumMap;
import java.util.Map;

public final class FeatureFlagRegistry {
    private final EnumMap<FeatureFlag, Boolean> states = new EnumMap<>(FeatureFlag.class);

    public FeatureFlagRegistry() {
        for (FeatureFlag flag : FeatureFlag.values()) {
            states.put(flag, flag.defaultEnabled());
        }
    }

    public synchronized boolean isEnabled(FeatureFlag flag) {
        return states.getOrDefault(flag, flag.defaultEnabled());
    }

    public synchronized void setInitial(FeatureFlag flag, boolean enabled) {
        states.put(flag, enabled);
    }

    public synchronized boolean reloadFlag(FeatureFlag flag, boolean requestedValue) {
        if (!flag.safeToReload()) {
            return false;
        }
        states.put(flag, requestedValue);
        return true;
    }

    public synchronized Map<FeatureFlag, Boolean> snapshot() {
        return Map.copyOf(states);
    }
}

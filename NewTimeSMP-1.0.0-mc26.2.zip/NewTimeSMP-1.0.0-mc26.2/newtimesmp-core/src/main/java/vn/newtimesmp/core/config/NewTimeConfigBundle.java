package vn.newtimesmp.core.config;

import java.util.Collections;
import java.util.Map;

public record NewTimeConfigBundle(
    int schemaVersion,
    boolean diagnosticsEnabled,
    String diagnosticsLevel,
    boolean redactSecrets,
    String compatibilityMode,
    boolean enforceThreadOwnershipChecks,
    String requestedProfile,
    boolean autoDetectHardware,
    boolean safeMode,
    int samplingIntervalTicks,
    int histogramWindowTicks,
    double slowTickThresholdMs,
    int configuredCpuWorkers,
    int configuredIoWorkers,
    int maxQueueCapacity,
    String rejectionPolicy,
    boolean experimentalRegionSchedulerEnabled,
    boolean experimentalAsyncEnabled,
    boolean experimentalAdaptiveTuningEnabled,
    Map<String, Object> rawPrimaryYaml
) {
    public NewTimeConfigBundle {
        rawPrimaryYaml = Collections.unmodifiableMap(rawPrimaryYaml);
    }
}

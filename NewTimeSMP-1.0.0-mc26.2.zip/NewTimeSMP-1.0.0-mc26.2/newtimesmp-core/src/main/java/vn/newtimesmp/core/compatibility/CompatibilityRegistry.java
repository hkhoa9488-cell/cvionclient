package vn.newtimesmp.core.compatibility;

import vn.newtimesmp.api.compatibility.CompatibilityStatus;
import vn.newtimesmp.api.compatibility.PluginCompatibilityRecord;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class CompatibilityRegistry {
    private final Map<String, PluginCompatibilityRecord> records = new ConcurrentHashMap<>();

    public void record(PluginCompatibilityRecord entry) {
        records.put(entry.pluginName().toLowerCase(), entry);
    }

    public CompatibilityStatus statusOf(String pluginName) {
        PluginCompatibilityRecord rec = records.get(pluginName.toLowerCase());
        return rec == null ? CompatibilityStatus.UNTESTED : rec.status();
    }

    public List<PluginCompatibilityRecord> allRecords() {
        return List.copyOf(new ArrayList<>(records.values()));
    }
}

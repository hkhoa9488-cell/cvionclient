package vn.newtimesmp.core.lifecycle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vn.newtimesmp.api.version.NewTimeVersionInfo;
import vn.newtimesmp.core.config.ConfigManager;
import vn.newtimesmp.core.config.NewTimeConfigBundle;
import vn.newtimesmp.core.featureflags.FeatureFlagRegistry;
import vn.newtimesmp.core.version.BuildMetadata;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Implements the 10-step startup and 8-step shutdown lifecycle defined in Blueprint Section 4.1.
 */
public final class NewTimeLifecycleManager {
    private static final Logger LOGGER = LoggerFactory.getLogger(NewTimeLifecycleManager.class);

    private final ConfigManager configManager;
    private final FeatureFlagRegistry flagRegistry;
    private final AtomicReference<LifecyclePhase> phase = new AtomicReference<>(LifecyclePhase.UNINITIALIZED);
    private final List<Runnable> shutdownHooks = new CopyOnWriteArrayList<>();
    private volatile NewTimeVersionInfo versionInfo;

    public NewTimeLifecycleManager(ConfigManager configManager, FeatureFlagRegistry flagRegistry) {
        this.configManager = configManager;
        this.flagRegistry = flagRegistry;
    }

    public NewTimeConfigBundle startup(Runnable hardwareInitHook, Runnable metricsInitHook, Runnable healthCheckHook) throws IOException {
        if (!phase.compareAndSet(LifecyclePhase.UNINITIALIZED, LifecyclePhase.STARTING)) {
            throw new IllegalStateException("Cannot start NewTimeSMP from phase " + phase.get());
        }
        // Step 1: Read build metadata
        this.versionInfo = BuildMetadata.load();
        LOGGER.info("[NewTimeSMP] Starting {}", versionInfo.displayBanner());

        // Step 2: Verify Java runtime compatibility (Java 21+ required for MC 26.2 Paper toolchain)
        int featureVersion = Runtime.version().feature();
        if (featureVersion < 21) {
            throw new IllegalStateException("Java 21+ is required for NewTimeSMP 1.0.0 (MC 26.2). Detected: " + featureVersion);
        }

        // Step 3: Parse & validate configuration (fail fast on invalid config)
        NewTimeConfigBundle config = configManager.loadAndValidate(flagRegistry, false);

        // Steps 4 & 5: Safe hardware detection & conservative profile selection (never overwrites admin config)
        if (hardwareInitHook != null) {
            hardwareInitHook.run();
        }

        // Step 6: Initialize logging/metrics
        if (metricsInitHook != null) {
            metricsInitHook.run();
        }

        // Steps 7 & 8: Delegated to upstream Paper server & plugin loader
        // Step 9: Health check
        if (healthCheckHook != null) {
            healthCheckHook.run();
        }

        // Step 10: Mark READY
        phase.set(LifecyclePhase.READY);
        LOGGER.info("[NewTimeSMP] Lifecycle READY (profile={}, safeMode={})", config.requestedProfile(), config.safeMode());
        return config;
    }

    public void registerShutdownHook(Runnable hook) {
        shutdownHooks.add(hook);
    }

    public void shutdown() {
        LifecyclePhase prev = phase.getAndSet(LifecyclePhase.STOPPING);
        if (prev == LifecyclePhase.STOPPED || prev == LifecyclePhase.STOPPING) {
            return;
        }
        LOGGER.info("[NewTimeSMP] Executing ordered shutdown sequence...");
        for (Runnable hook : shutdownHooks) {
            try {
                hook.run();
            } catch (Exception e) {
                LOGGER.error("[NewTimeSMP] Non-fatal error during shutdown step", e);
            }
        }
        phase.set(LifecyclePhase.STOPPED);
        LOGGER.info("[NewTimeSMP] Shutdown complete.");
    }

    public LifecyclePhase phase() {
        return phase.get();
    }

    public NewTimeVersionInfo versionInfo() {
        return versionInfo;
    }
}

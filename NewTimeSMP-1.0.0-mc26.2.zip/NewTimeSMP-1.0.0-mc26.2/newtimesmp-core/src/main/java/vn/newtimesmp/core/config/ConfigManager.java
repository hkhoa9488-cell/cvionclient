package vn.newtimesmp.core.config;

import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.SafeConstructor;
import vn.newtimesmp.api.featureflags.FeatureFlag;
import vn.newtimesmp.core.featureflags.FeatureFlagRegistry;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public final class ConfigManager {
    public static final int EXPECTED_SCHEMA_VERSION = 1;
    private static final Set<String> VALID_PROFILES = Set.of("AUTO", "LEGACY", "STANDARD", "PERFORMANCE", "HIGH_PERFORMANCE");
    private static final Set<String> VALID_DIAG_LEVELS = Set.of("MINIMAL", "STANDARD", "VERBOSE");
    private static final Set<String> VALID_REJECTION_POLICIES = Set.of("CALLER_RUNS", "ABORT_WITH_METRIC");

    private final Path configDir;
    private volatile NewTimeConfigBundle currentBundle;

    public ConfigManager(Path configDir) {
        this.configDir = configDir;
    }

    public NewTimeConfigBundle loadAndValidate(FeatureFlagRegistry flagRegistry, boolean isReload) throws IOException {
        Files.createDirectories(configDir);
        Path primaryPath = configDir.resolve("newtimesmp.yml");
        Path perfPath = configDir.resolve("performance.yml");
        Path expPath = configDir.resolve("experimental.yml");

        copyDefaultIfMissing(primaryPath, "defaults/newtimesmp.yml");
        copyDefaultIfMissing(perfPath, "defaults/performance.yml");
        copyDefaultIfMissing(expPath, "defaults/experimental.yml");

        Map<String, Object> primary = parseYaml(primaryPath, "newtimesmp.yml");
        Map<String, Object> perf = parseYaml(perfPath, "performance.yml");
        Map<String, Object> exp = parseYaml(expPath, "experimental.yml");

        int schemaVersion = requirePositiveInt(primary, "newtimesmp.yml", "settings.version");
        if (schemaVersion != EXPECTED_SCHEMA_VERSION) {
            throw new ConfigValidationException("newtimesmp.yml", "settings.version",
                "Unsupported schema version " + schemaVersion + " (expected " + EXPECTED_SCHEMA_VERSION + ")");
        }

        boolean diagnosticsEnabled = requireBoolean(primary, "newtimesmp.yml", "diagnostics.enabled");
        String diagnosticsLevel = requireEnumString(primary, "newtimesmp.yml", "diagnostics.level", VALID_DIAG_LEVELS);
        boolean redactSecrets = requireBoolean(primary, "newtimesmp.yml", "diagnostics.redact-secrets");

        String compatibilityMode = requireString(primary, "newtimesmp.yml", "compatibility.mode");
        boolean enforceOwnership = requireBoolean(primary, "newtimesmp.yml", "compatibility.enforce-thread-ownership-checks");

        String requestedProfile = requireEnumString(primary, "newtimesmp.yml", "performance.profile", VALID_PROFILES);
        boolean autoDetect = requireBoolean(primary, "newtimesmp.yml", "performance.auto-detect");
        boolean safeMode = requireBoolean(primary, "newtimesmp.yml", "performance.safe-mode");

        int samplingInterval = requirePositiveInt(perf, "performance.yml", "observability.sampling-interval-ticks");
        int histogramWindow = requirePositiveInt(perf, "performance.yml", "observability.histogram-window-ticks");
        double slowTickMs = requirePositiveDouble(perf, "performance.yml", "observability.slow-tick-threshold-ms");

        int cpuWorkers = requireNonNegativeInt(perf, "performance.yml", "executors.cpu-workers");
        int ioWorkers = requirePositiveInt(perf, "performance.yml", "executors.io-workers");
        int queueCap = requirePositiveInt(perf, "performance.yml", "executors.max-queue-capacity");
        String rejectionPolicy = requireEnumString(perf, "performance.yml", "executors.rejection-policy", VALID_REJECTION_POLICIES);

        boolean expRegion = requireBoolean(exp, "experimental.yml", "region-scheduler.enabled");
        boolean expAsync = requireBoolean(exp, "experimental.yml", "async-experiments.enabled");
        boolean expAdaptive = requireBoolean(exp, "experimental.yml", "adaptive-tuning.enabled");

        if (safeMode && (expRegion || expAsync || expAdaptive)) {
            throw new ConfigValidationException("experimental.yml", "region-scheduler.enabled",
                "Cannot enable experimental flags while performance.safe-mode=true in newtimesmp.yml");
        }

        NewTimeConfigBundle validated = new NewTimeConfigBundle(
            schemaVersion,
            diagnosticsEnabled,
            diagnosticsLevel,
            redactSecrets,
            compatibilityMode,
            enforceOwnership,
            requestedProfile,
            autoDetect,
            safeMode,
            samplingInterval,
            histogramWindow,
            slowTickMs,
            cpuWorkers,
            ioWorkers,
            queueCap,
            rejectionPolicy,
            expRegion,
            expAsync,
            expAdaptive,
            primary
        );

        applyFlags(flagRegistry, validated, isReload);
        this.currentBundle = validated;
        return validated;
    }

    public Path createBackup(String fileName) throws IOException {
        Path source = configDir.resolve(fileName);
        if (!Files.exists(source)) {
            throw new IOException("Config file does not exist: " + source);
        }
        String suffix = ".bak." + Instant.now().toEpochMilli();
        Path backup = configDir.resolve(fileName + suffix);
        Files.copy(source, backup, StandardCopyOption.REPLACE_EXISTING);
        return backup;
    }

    public NewTimeConfigBundle current() {
        return currentBundle;
    }

    private void applyFlags(FeatureFlagRegistry registry, NewTimeConfigBundle b, boolean isReload) {
        if (!isReload) {
            registry.setInitial(FeatureFlag.DIAGNOSTICS_ENABLED, b.diagnosticsEnabled());
            registry.setInitial(FeatureFlag.HARDWARE_AUTO_PROFILE, b.autoDetectHardware());
            registry.setInitial(FeatureFlag.BOUNDED_EXECUTORS, !b.safeMode());
            registry.setInitial(FeatureFlag.EXPERIMENTAL_REGION_SCHEDULER, b.experimentalRegionSchedulerEnabled());
            registry.setInitial(FeatureFlag.EXPERIMENTAL_ASYNC_TASKS, b.experimentalAsyncEnabled());
            registry.setInitial(FeatureFlag.EXPERIMENTAL_ADAPTIVE_TUNING, b.experimentalAdaptiveTuningEnabled());
        } else {
            registry.reloadFlag(FeatureFlag.DIAGNOSTICS_ENABLED, b.diagnosticsEnabled());
            registry.reloadFlag(FeatureFlag.OBSERVABILITY_COLLECTOR, true);
        }
    }

    private void copyDefaultIfMissing(Path target, String resourcePath) throws IOException {
        if (Files.exists(target)) {
            return;
        }
        try (InputStream in = ConfigManager.class.getClassLoader().getResourceAsStream(resourcePath)) {
            if (in == null) {
                throw new IOException("Missing embedded default config resource: " + resourcePath);
            }
            Files.copy(in, target);
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseYaml(Path path, String fileName) throws IOException {
        LoaderOptions options = new LoaderOptions();
        options.setAllowDuplicateKeys(false);
        Yaml yaml = new Yaml(new SafeConstructor(options));
        try (InputStream in = Files.newInputStream(path)) {
            Object loaded = yaml.load(in);
            if (!(loaded instanceof Map<?, ?> map)) {
                throw new ConfigValidationException(fileName, "<root>", "YAML root must be a key-value mapping");
            }
            Map<String, Object> result = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                result.put(String.valueOf(entry.getKey()), entry.getValue());
            }
            return result;
        } catch (ConfigValidationException e) {
            throw e;
        } catch (RuntimeException e) {
            throw new ConfigValidationException(fileName, "<syntax>", "Malformed YAML syntax: " + e.getMessage());
        }
    }

    private Object resolvePath(Map<String, Object> root, String fileName, String path) {
        String[] parts = path.split("\\.");
        Object current = root;
        for (String part : parts) {
            if (!(current instanceof Map<?, ?> map) || !map.containsKey(part)) {
                throw new ConfigValidationException(fileName, path, "Missing required configuration key");
            }
            current = map.get(part);
        }
        return current;
    }

    private boolean requireBoolean(Map<String, Object> root, String fileName, String path) {
        Object val = resolvePath(root, fileName, path);
        if (!(val instanceof Boolean b)) {
            throw new ConfigValidationException(fileName, path, "Expected boolean, got: " + val);
        }
        return b;
    }

    private int requirePositiveInt(Map<String, Object> root, String fileName, String path) {
        Object val = resolvePath(root, fileName, path);
        if (!(val instanceof Number n) || n.intValue() <= 0) {
            throw new ConfigValidationException(fileName, path, "Expected positive integer (>0), got: " + val);
        }
        return n.intValue();
    }

    private int requireNonNegativeInt(Map<String, Object> root, String fileName, String path) {
        Object val = resolvePath(root, fileName, path);
        if (!(val instanceof Number n) || n.intValue() < 0) {
            throw new ConfigValidationException(fileName, path, "Expected non-negative integer (>=0), got: " + val);
        }
        return n.intValue();
    }

    private double requirePositiveDouble(Map<String, Object> root, String fileName, String path) {
        Object val = resolvePath(root, fileName, path);
        if (!(val instanceof Number n) || n.doubleValue() <= 0.0) {
            throw new ConfigValidationException(fileName, path, "Expected positive number (>0), got: " + val);
        }
        return n.doubleValue();
    }

    private String requireString(Map<String, Object> root, String fileName, String path) {
        Object val = resolvePath(root, fileName, path);
        if (!(val instanceof String s) || s.isBlank()) {
            throw new ConfigValidationException(fileName, path, "Expected non-empty string, got: " + val);
        }
        return s.trim();
    }

    private String requireEnumString(Map<String, Object> root, String fileName, String path, Set<String> allowed) {
        String s = requireString(root, fileName, path).toUpperCase();
        if (!allowed.contains(s)) {
            throw new ConfigValidationException(fileName, path, "Invalid value '" + s + "'. Allowed: " + allowed);
        }
        return s;
    }
}

package vn.newtimesmp.core.config;

public final class ConfigValidationException extends RuntimeException {
    private final String fileName;
    private final String keyPath;

    public ConfigValidationException(String fileName, String keyPath, String message) {
        super("[" + fileName + " -> " + keyPath + "] " + message);
        this.fileName = fileName;
        this.keyPath = keyPath;
    }

    public String fileName() {
        return fileName;
    }

    public String keyPath() {
        return keyPath;
    }
}

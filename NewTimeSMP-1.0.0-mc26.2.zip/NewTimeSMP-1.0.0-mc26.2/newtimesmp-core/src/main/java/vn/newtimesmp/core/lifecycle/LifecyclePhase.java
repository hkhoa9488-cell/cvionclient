package vn.newtimesmp.core.lifecycle;

public enum LifecyclePhase {
    UNINITIALIZED,
    STARTING,
    READY,
    STOPPING,
    STOPPED
}

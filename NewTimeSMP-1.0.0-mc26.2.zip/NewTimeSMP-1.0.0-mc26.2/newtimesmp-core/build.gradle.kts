dependencies {
    api(project(":newtimesmp-api"))
    implementation(libs.snakeyaml)
    implementation(libs.slf4j.api)

    testImplementation(libs.junit.jupiter)
    testImplementation(libs.assertj.core)
    testRuntimeOnly(libs.slf4j.simple)
}

tasks.processResources {
    filesMatching("newtimesmp-build.properties") {
        expand(
            "version" to project.findProperty("newtimesmpVersion").toString(),
            "minecraftVersion" to project.findProperty("minecraftVersion").toString()
        )
    }
}

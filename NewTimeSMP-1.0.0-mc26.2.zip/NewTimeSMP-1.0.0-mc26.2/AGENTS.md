# AGENTS.md — Token-Efficient AI Coding Protocol for NewTimeSMP

## 1. Mandatory Context Loading Order (Do NOT load full repo)
1. Read `PROJECT_STATE.md` (~350 tokens) and `TASK.md` (~250 tokens).
2. Read `docs/INDEX.md` to locate the single relevant L2/L3 spec.
3. Use `rg` (ripgrep) to locate exact symbols/call paths before opening `.java` files.
4. Open ONLY the target file(s) listed in `TASK.md`. Never dump whole modules into context.

## 2. Non-Negotiable Engineering Invariants
- **Priority Order**: Correctness & data safety > Stability > Plugin/API compatibility > Reproducible build > Diagnostics > Measured performance > Experimental scheduling > Optional features.
- **Thread Ownership**: Never call Bukkit/Paper world/chunk/entity mutations from async worker pools.
- **Config Safety**: Validate schema version on startup; fail fast on malformed config; never overwrite admin overrides; only reload keys marked `safe-to-reload`.
- **No Unverified Claims**: Never mark a build/test/benchmark `PASS` without real execution logs in `docs/evidence/`.

## 3. Standard Task Execution Loop
1. State call path, invariants, risks, and required tests BEFORE editing code.
2. Edit one minimal vertical slice.
3. Run targeted Gradle build + JUnit tests (`./gradlew test`).
4. Update `PROJECT_STATE.md` and `TASK.md` with real command output.

# NewTimeSMP Upstream Patches (Paper 26.2)

Patches follow Paper's patch workflow and are separated into strict categories:
- `patches/api/` — Minimal API bridges to `newtimesmp-api`.
- `patches/server/` — Lifecycle & command hooks into `newtimesmp-core` and `newtimesmp-diagnostics`.
- `patches/observability/` — Non-blocking tick duration hook (`ServerMetricsCollector#recordTickNanos`).
- `patches/performance/` — Benchmark-proven hot-path cleanups only (each requires ADR + A/B report).
- `patches/experimental/` — Isolated region scheduler hooks (disabled unless `experimental.region-scheduler.enabled=true`).

# Licenses & Upstream Attribution

- **NewTimeSMP Modules (`newtimesmp-*`)**: Licensed under GPL-3.0-only (matching Paper server distribution requirements) with API interfaces compatible with MIT/GPL plugin ecosystems.
- **Paper Upstream (`PaperMC/Paper`)**: Copyright (c) PaperMC contributors. Retain upstream license headers and patch attribution in `patches/`.
- **Selective Third-Party Research (Leaf / Purpur / Folia)**: Any patch adapted in `patches/` must explicitly document upstream repository URL, commit SHA, original author, and license compatibility before merge.

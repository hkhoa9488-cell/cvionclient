# NewTimeSMP Benchmark Harness (MC 26.2)

## Mandatory Environment Record
Every benchmark run must record:
- NewTimeSMP commit & Paper `26.2` commit (`UPSTREAM.lock`)
- Java vendor/version & exact JVM flags
- CPU model, logical cores, cgroup limits, RAM, NVMe/SSD storage, OS
- World seed, view-distance, simulation-distance, plugin list + versions
- Staged player load: `20 -> 50 -> 100 -> 150 -> 200` (never jump directly to max load)
- Metrics: TPS (1m/5m/15m), MSPT `p50`/`p95`/`p99`, `ticks > 50ms`, GC pause, peak heap, queue depth.

# ROADMAP.md — NewTimeSMP Release Milestones (Target: MC 26.2)

- **NT-0.0.1 / Repository Audit**: Pin Paper `26.2` commit in `UPSTREAM.lock`, verify clean upstream build (`scripts/verify-upstream.sh`).
- **NT-0.1.0 / Foundation**: `newtimesmp-api` + `newtimesmp-core` (metadata, strict YAML config validation/backup, feature flags, 10-step startup & 8-step shutdown).
- **NT-0.2.0 / Compatibility Baseline**: `CompatibilityRegistry` (`PASS`/`FAIL`/`UNTESTED`/`UNSUPPORTED`) & plugin lifecycle/save-load regression suite.
- **NT-0.3.0 / Observability**: `newtimesmp-observability` lock-free MSPT histogram (p50/p95/p99), rolling TPS, ticks > 50ms, GC/heap/chunk/entity/network metrics.
- **NT-0.4.0 / Hardware Profiles**: `newtimesmp-hardware` cgroup v1/v2 + CPU/RAM detection, conservative presets (`Legacy`, `Standard`, `Performance`, `High Performance`).
- **NT-0.5.0 / Safe Performance**: `newtimesmp-performance` bounded executors with backpressure & bounded LRU caches (A/B benchmark gated).
- **NT-0.6.0 / Leaf Research & Selective Port**: Patch audit workflow (`scripts/verify-patches.sh`) with license/attribution tracking.
- **NT-0.7.0 – NT-0.8.0 / Experimental Scheduler**: `newtimesmp-experimental` isolated ownership guards & scheduler contracts (`enabled: false` by default).
- **NT-0.9.0 / Scale Candidate**: Staged load tests (20 -> 50 -> 100 -> 150 -> 200 simulated players) & multi-hour soak verification.
- **NT-1.0.0 / Stable Release (Current Release Target)**: Release gate checklist, redacted diagnostics (`/newtimesmp`), reproducible build, and documented limitations.

# Changelog

## [1.0.0] - 2026-11-22 (Minecraft 26.2 Target)
### Added
- Multi-module architecture (`newtimesmp-api`, `newtimesmp-core`, `newtimesmp-observability`, `newtimesmp-hardware`, `newtimesmp-diagnostics`, `newtimesmp-performance`, `newtimesmp-experimental`).
- Strict YAML configuration loader with schema version checks, automatic `.bak` backups, unknown-key preservation, and `safe-to-reload` enforcement (`newtimesmp.yml`, `performance.yml`, `hardware-profiles.yml`, `experimental.yml`).
- Lock-free ring-buffer tick histogram (`p50`/`p95`/`p99` MSPT, rolling TPS, `ticks > 50ms`) with zero main-thread blocking.
- Cgroup v1/v2 and runtime hardware detector with conservative profile selection (`Legacy`, `Standard`, `Performance`, `High Performance`).
- `/newtimesmp` diagnostics & management commands with permission checks, audit logging, and automatic IP/token/password redaction.
- Bounded task executor with backpressure and bounded LRU cache primitives.
- Token-efficient L0–L5 documentation & AI workflow (`PROJECT_STATE.md`, `AGENTS.md`, `scripts/context-pack.sh`).

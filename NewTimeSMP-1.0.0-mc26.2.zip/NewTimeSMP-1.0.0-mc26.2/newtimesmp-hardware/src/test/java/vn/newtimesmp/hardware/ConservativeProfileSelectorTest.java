package vn.newtimesmp.hardware;

import org.junit.jupiter.api.Test;
import vn.newtimesmp.api.hardware.HardwareTier;
import vn.newtimesmp.hardware.profiles.ConservativeProfileSelector;

import static org.assertj.core.api.Assertions.assertThat;

class ConservativeProfileSelectorTest {

    @Test
    void respectsSafeModeAndAdminOverrides() {
        ConservativeProfileSelector selector = new ConservativeProfileSelector();
        var safeSnap = selector.detectAndSelect("HIGH_PERFORMANCE", true, true);
        assertThat(safeSnap.selectedTier()).isEqualTo(HardwareTier.LEGACY);

        var overrideSnap = selector.detectAndSelect("PERFORMANCE", true, false);
        assertThat(overrideSnap.selectedTier()).isEqualTo(HardwareTier.PERFORMANCE);
        assertThat(overrideSnap.adminOverridden()).isTrue();
    }
}

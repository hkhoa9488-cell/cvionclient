package vn.newtimesmp.hardware.profiles;

import vn.newtimesmp.api.hardware.HardwareProfileSnapshot;
import vn.newtimesmp.api.hardware.HardwareTier;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Detects runtime CPU/JVM/cgroup limits safely and selects a conservative profile
 * without relying solely on host CPU core count or overriding explicit admin settings.
 */
public final class ConservativeProfileSelector {

    public HardwareProfileSnapshot detectAndSelect(String requestedProfile, boolean autoDetect, boolean safeMode) {
        int hostCpus = Math.max(1, Runtime.getRuntime().availableProcessors());
        long jvmMaxHeap = Runtime.getRuntime().maxMemory();
        double cgroupCpuLimit = readCgroupCpuLimit(hostCpus);
        long cgroupMemLimit = readCgroupMemoryLimit();

        double effectiveCpus = Math.min(hostCpus, cgroupCpuLimit);
        long effectiveMemBytes = (cgroupMemLimit > 0 && cgroupMemLimit < jvmMaxHeap) ? cgroupMemLimit : jvmMaxHeap;

        List<String> reasons = new ArrayList<>();
        reasons.add(String.format("Host logical CPUs=%d, effectiveCpus=%.2f", hostCpus, effectiveCpus));
        reasons.add(String.format("JVM maxHeap=%dMB, containerMemLimit=%s",
            jvmMaxHeap / (1024 * 1024),
            cgroupMemLimit > 0 ? (cgroupMemLimit / (1024 * 1024)) + "MB" : "unbounded/host"));

        HardwareTier selected;
        boolean adminOverridden = false;

        if (safeMode) {
            selected = HardwareTier.LEGACY;
            adminOverridden = true;
            reasons.add("performance.safe-mode=true forces conservative LEGACY profile");
        } else if (!"AUTO".equalsIgnoreCase(requestedProfile) || !autoDetect) {
            selected = parseTier(requestedProfile);
            adminOverridden = true;
            reasons.add("Explicit admin profile override: " + selected.name());
        } else {
            selected = selectConservativeTier(effectiveCpus, effectiveMemBytes, reasons);
        }

        int cpuWorkers = switch (selected) {
            case LEGACY -> 1;
            case STANDARD -> 2;
            case PERFORMANCE -> 4;
            case HIGH_PERFORMANCE -> 8;
        };
        int ioWorkers = (selected == HardwareTier.LEGACY) ? 1 : (selected == HardwareTier.STANDARD ? 2 : 4);

        return new HardwareProfileSnapshot(
            selected,
            adminOverridden,
            hostCpus,
            effectiveCpus,
            jvmMaxHeap,
            cgroupMemLimit,
            System.getProperty("java.vm.vendor", "unknown"),
            System.getProperty("java.version", "unknown"),
            System.getProperty("os.arch", "unknown"),
            cpuWorkers,
            ioWorkers,
            List.copyOf(reasons)
        );
    }

    HardwareTier selectConservativeTier(double effectiveCpus, long effectiveMemBytes, List<String> reasons) {
        long memMb = effectiveMemBytes / (1024L * 1024L);
        if (effectiveCpus >= 16.0 && memMb >= 16384L) {
            reasons.add("Auto-selected HIGH_PERFORMANCE (effectiveCpus>=16 and effectiveMem>=16GB)");
            return HardwareTier.HIGH_PERFORMANCE;
        }
        if (effectiveCpus >= 8.0 && memMb >= 8192L) {
            reasons.add("Auto-selected PERFORMANCE (effectiveCpus>=8 and effectiveMem>=8GB)");
            return HardwareTier.PERFORMANCE;
        }
        if (effectiveCpus >= 4.0 && memMb >= 4096L) {
            reasons.add("Auto-selected STANDARD (effectiveCpus>=4 and effectiveMem>=4GB)");
            return HardwareTier.STANDARD;
        }
        reasons.add("Auto-selected conservative LEGACY tier due to CPU quota or RAM ceiling");
        return HardwareTier.LEGACY;
    }

    private HardwareTier parseTier(String value) {
        return switch (value.toUpperCase()) {
            case "LEGACY" -> HardwareTier.LEGACY;
            case "PERFORMANCE" -> HardwareTier.PERFORMANCE;
            case "HIGH_PERFORMANCE" -> HardwareTier.HIGH_PERFORMANCE;
            default -> HardwareTier.STANDARD;
        };
    }

    private double readCgroupCpuLimit(int fallback) {
        try {
            Path v2 = Path.of("/sys/fs/cgroup/cpu.max");
            if (Files.isReadable(v2)) {
                String[] parts = Files.readString(v2).trim().split("\\s+");
                if (parts.length == 2 && !"max".equals(parts[0])) {
                    double quota = Double.parseDouble(parts[0]);
                    double period = Double.parseDouble(parts[1]);
                    if (period > 0) {
                        return Math.max(0.5, quota / period);
                    }
                }
            }
            Path v1Quota = Path.of("/sys/fs/cgroup/cpu/cpu.cfs_quota_us");
            Path v1Period = Path.of("/sys/fs/cgroup/cpu/cpu.cfs_period_us");
            if (Files.isReadable(v1Quota) && Files.isReadable(v1Period)) {
                double quota = Double.parseDouble(Files.readString(v1Quota).trim());
                double period = Double.parseDouble(Files.readString(v1Period).trim());
                if (quota > 0 && period > 0) {
                    return Math.max(0.5, quota / period);
                }
            }
        } catch (IOException | NumberFormatException ignored) {
            // Safe fallback on non-Linux or restricted containers
        }
        return fallback;
    }

    private long readCgroupMemoryLimit() {
        try {
            Path v2 = Path.of("/sys/fs/cgroup/memory.max");
            if (Files.isReadable(v2)) {
                String raw = Files.readString(v2).trim();
                if (!"max".equals(raw)) {
                    return Long.parseLong(raw);
                }
            }
            Path v1 = Path.of("/sys/fs/cgroup/memory/memory.limit_in_bytes");
            if (Files.isReadable(v1)) {
                long val = Long.parseLong(Files.readString(v1).trim());
                if (val > 0 && val < (1L << 60)) {
                    return val;
                }
            }
        } catch (IOException | NumberFormatException ignored) {
            // Safe fallback
        }
        return -1L;
    }
}

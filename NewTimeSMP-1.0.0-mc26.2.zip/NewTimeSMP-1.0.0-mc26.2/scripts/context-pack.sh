#!/usr/bin/env bash
set -euo pipefail

# Emits ~800 tokens of essential L0/L1 context for AI coding sessions
echo "=== PROJECT_STATE.md ==="
cat PROJECT_STATE.md
echo ""
echo "=== TASK.md ==="
cat TASK.md
echo ""
echo "=== UPSTREAM.lock ==="
cat UPSTREAM.lock
echo ""
echo "=== GIT STATUS ==="
git status -s 2>/dev/null || echo "(not yet initialized as git repo)"

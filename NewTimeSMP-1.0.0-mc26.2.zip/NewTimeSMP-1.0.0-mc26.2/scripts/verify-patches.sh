#!/usr/bin/env bash
set -euo pipefail

echo "[NewTimeSMP] Verifying patch directory hygiene..."
for dir in patches/api patches/server patches/observability patches/performance patches/experimental; do
  mkdir -p "$dir"
done
echo "[NewTimeSMP] Patch directories verified."

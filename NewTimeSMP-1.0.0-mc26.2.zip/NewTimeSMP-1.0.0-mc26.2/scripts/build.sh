#!/usr/bin/env bash
set -euo pipefail

echo "[NewTimeSMP] Building NewTimeSMP 1.0.0 (Minecraft 26.2)..."
./scripts/verify-patches.sh
gradle test assemble
echo "[NewTimeSMP] Build and module tests completed."

#!/usr/bin/env python3
"""Compares baseline vs candidate NewTimeSMP JSON benchmark reports."""
import json
import sys

def main():
    if len(sys.argv) != 3:
        print("Usage: compare-benchmarks.py <baseline.json> <candidate.json>")
        sys.exit(1)
    with open(sys.argv[1], "r", encoding="utf-8") as f:
        base = json.load(f)
    with open(sys.argv[2], "r", encoding="utf-8") as f:
        cand = json.load(f)

    metrics = ["tps1m", "msptP50", "msptP95", "msptP99", "ticksOver50Ms"]
    print(f"{'Metric':<18} {'Baseline':>12} {'Candidate':>12} {'Delta':>12}")
    print("-" * 58)
    for m in metrics:
        b = float(base.get(m, 0.0))
        c = float(cand.get(m, 0.0))
        delta = c - b
        print(f"{m:<18} {b:>12.2f} {c:>12.2f} {delta:>+12.2f}")

if __name__ == "__main__":
    main()

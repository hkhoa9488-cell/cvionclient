@echo off
echo [NewTimeSMP] Building NewTimeSMP 1.0.0 (Minecraft 26.2)...
call gradle test assemble
if %errorlevel% neq 0 exit /b %errorlevel%
echo [NewTimeSMP] Build completed.

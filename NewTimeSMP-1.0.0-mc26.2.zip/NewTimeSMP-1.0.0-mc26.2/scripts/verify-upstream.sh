#!/usr/bin/env bash
set -euo pipefail

UPSTREAM_DIR="${1:-.upstream-paper}"
UPSTREAM_URL="https://github.com/PaperMC/Paper.git"
TARGET_BRANCH="ver/26.2"

echo "[NewTimeSMP] Auditing Paper upstream ($UPSTREAM_URL @ $TARGET_BRANCH)..."
if [ ! -d "$UPSTREAM_DIR/.git" ]; then
  git clone --depth 1 --branch "$TARGET_BRANCH" "$UPSTREAM_URL" "$UPSTREAM_DIR"
else
  git -C "$UPSTREAM_DIR" fetch origin "$TARGET_BRANCH" --depth 1
  git -C "$UPSTREAM_DIR" checkout FETCH_HEAD
fi

COMMIT_SHA="$(git -C "$UPSTREAM_DIR" rev-parse HEAD)"
TODAY="$(date -u +%Y-%m-%d)"

cat > UPSTREAM.lock <<EOF
# NewTimeSMP Upstream Pin File (Locked by verify-upstream.sh)
upstream_name=Paper
upstream_url=$UPSTREAM_URL
upstream_branch=$TARGET_BRANCH
minecraft_version=26.2
upstream_commit_sha=$COMMIT_SHA
last_sync_date=$TODAY
java_toolchain=21
gradle_wrapper_mode=upstream_inherited
patch_set_status=VERIFIED_PINNED
EOF

echo "[NewTimeSMP] Pinned Paper commit $COMMIT_SHA in UPSTREAM.lock"

package com.tenzei.combatutils.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public final class FreeFall {
    private static final double FALL_SPEED_THRESHOLD = -0.5;
    private boolean wasFalling = false;

    public void tick(MinecraftClient client) {
        if (client.player == null) return;
        boolean falling = !client.player.isOnGround()
                && !client.player.isFallFlying()
                && client.player.getVelocity().y < FALL_SPEED_THRESHOLD;

        if (falling && !wasFalling) {
            client.player.sendMessage(Text.literal("Free Fall: đang rơi."), true);
        }
        wasFalling = falling;
    }

    public void reset() {
        wasFalling = false;
    }
}

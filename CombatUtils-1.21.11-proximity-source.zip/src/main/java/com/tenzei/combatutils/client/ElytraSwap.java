package com.tenzei.combatutils.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public final class ElytraSwap {
    private static final int CHEST_SLOT_ID = 6;
    private int proximityCounter = 0;
    private int swapCooldown = 0;
    private boolean lastWantedChestplate = false;
    private boolean hasPreviousTargetState = false;

    public boolean toggleChestEquipment(MinecraftClient client) {
        if (client.player == null || client.interactionManager == null) return false;

        ItemStack equipped = client.player.getEquippedStack(EquipmentSlot.CHEST);
        boolean wearingElytra = equipped.isOf(Items.ELYTRA);

        for (int hotbar = 0; hotbar < 9; hotbar++) {
            ItemStack stack = client.player.getInventory().getStack(hotbar);
            boolean isTarget = wearingElytra ? isChestplate(stack) : stack.isOf(Items.ELYTRA);
            if (isTarget) return swapChestSlotWithHotbar(client, hotbar);
        }
        return false;
    }

    public void tickProximity(MinecraftClient client, ModConfig config) {
        if (client.player == null || client.world == null || client.interactionManager == null) return;
        if (swapCooldown > 0) swapCooldown--;

        if (!config.autoSwapEnabled) {
            proximityCounter = 0;
            hasPreviousTargetState = false;
            return;
        }

        PlayerEntity player = client.player;
        double rangeSq = (double) config.rangeBlocks * config.rangeBlocks;
        boolean opponentNearby = client.world.getPlayers().stream()
                .anyMatch(other -> other != player
                        && !other.isSpectator()
                        && other.isAlive()
                        && player.squaredDistanceTo(other) <= rangeSq);

        // Hysteresis avoids rapid swaps exactly at the configured range boundary.
        boolean wantsChestplate = opponentNearby;
        if (!hasPreviousTargetState || wantsChestplate != lastWantedChestplate) {
            proximityCounter = 0;
            lastWantedChestplate = wantsChestplate;
            hasPreviousTargetState = true;
        } else {
            proximityCounter++;
        }

        if (proximityCounter < config.reactionTicks || swapCooldown > 0) return;

        ItemStack equipped = player.getEquippedStack(EquipmentSlot.CHEST);
        if (wantsChestplate && equipped.isOf(Items.ELYTRA)) {
            if (findAndSwap(client, true)) finishSwap();
        } else if (!wantsChestplate && isChestplate(equipped)) {
            if (findAndSwap(client, false)) finishSwap();
        }
    }

    private boolean findAndSwap(MinecraftClient client, boolean wantChestplate) {
        for (int hotbar = 0; hotbar < 9; hotbar++) {
            ItemStack stack = client.player.getInventory().getStack(hotbar);
            if (wantChestplate ? isChestplate(stack) : stack.isOf(Items.ELYTRA)) {
                return swapChestSlotWithHotbar(client, hotbar);
            }
        }
        return false;
    }

    private boolean swapChestSlotWithHotbar(MinecraftClient client, int hotbar) {
        client.interactionManager.clickSlot(
                client.player.playerScreenHandler.syncId,
                CHEST_SLOT_ID,
                hotbar,
                SlotActionType.SWAP,
                client.player
        );
        return true;
    }

    private void finishSwap() {
        swapCooldown = 2;
        proximityCounter = 0;
    }

    private static boolean isChestplate(ItemStack stack) {
        return stack.isOf(Items.LEATHER_CHESTPLATE)
                || stack.isOf(Items.CHAINMAIL_CHESTPLATE)
                || stack.isOf(Items.IRON_CHESTPLATE)
                || stack.isOf(Items.GOLDEN_CHESTPLATE)
                || stack.isOf(Items.DIAMOND_CHESTPLATE)
                || stack.isOf(Items.NETHERITE_CHESTPLATE);
    }
}

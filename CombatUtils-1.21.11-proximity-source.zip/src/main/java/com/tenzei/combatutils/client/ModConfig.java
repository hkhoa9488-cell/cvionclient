package com.tenzei.combatutils.client;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class ModConfig {
    private static final Path FILE = FabricLoader.getInstance()
            .getConfigDir().resolve("combat-utils.properties");

    public boolean autoSwapEnabled = false;
    public int rangeBlocks = 8;
    public int reactionTicks = 1;

    public static ModConfig load() {
        ModConfig config = new ModConfig();
        if (!Files.exists(FILE)) {
            config.save();
            return config;
        }
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(FILE)) {
            p.load(in);
            config.autoSwapEnabled = Boolean.parseBoolean(
                    p.getProperty("autoSwapEnabled", "false"));
            config.rangeBlocks = clamp(parseInt(p.getProperty("rangeBlocks"), 8), 2, 32);
            config.reactionTicks = clamp(parseInt(p.getProperty("reactionTicks"), 1), 0, 20);
        } catch (IOException ignored) {
            // Keep safe defaults if config cannot be read.
        }
        return config;
    }

    public void save() {
        Properties p = new Properties();
        p.setProperty("autoSwapEnabled", Boolean.toString(autoSwapEnabled));
        p.setProperty("rangeBlocks", Integer.toString(rangeBlocks));
        p.setProperty("reactionTicks", Integer.toString(reactionTicks));
        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream out = Files.newOutputStream(FILE)) {
                p.store(out, "Combat Utils settings");
            }
        } catch (IOException ignored) {
            // Settings remain active for this session even if saving fails.
        }
    }

    private static int parseInt(String value, int fallback) {
        try { return Integer.parseInt(value); }
        catch (RuntimeException ignored) { return fallback; }
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}

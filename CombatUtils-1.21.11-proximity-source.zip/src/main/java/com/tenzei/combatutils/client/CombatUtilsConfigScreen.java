package com.tenzei.combatutils.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class CombatUtilsConfigScreen extends Screen {
    private final Screen parent;
    private ButtonWidget autoButton;
    private ButtonWidget rangeButton;
    private ButtonWidget reactionButton;

    public CombatUtilsConfigScreen(Screen parent) {
        super(Text.literal("Combat Utils Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int center = this.width / 2;
        int y = this.height / 4;

        autoButton = ButtonWidget.builder(autoLabel(), button -> {
            CombatUtilsClient.CONFIG.autoSwapEnabled = !CombatUtilsClient.CONFIG.autoSwapEnabled;
            CombatUtilsClient.CONFIG.save();
            refreshLabels();
        }).dimensions(center - 110, y, 220, 20).build();
        addDrawableChild(autoButton);

        rangeButton = ButtonWidget.builder(rangeLabel(), button -> {
            int current = CombatUtilsClient.CONFIG.rangeBlocks;
            CombatUtilsClient.CONFIG.rangeBlocks = current >= 32 ? 2 : current + 2;
            CombatUtilsClient.CONFIG.save();
            refreshLabels();
        }).dimensions(center - 110, y + 28, 220, 20).build();
        addDrawableChild(rangeButton);

        reactionButton = ButtonWidget.builder(reactionLabel(), button -> {
            int current = CombatUtilsClient.CONFIG.reactionTicks;
            CombatUtilsClient.CONFIG.reactionTicks = current >= 5 ? 0 : current + 1;
            CombatUtilsClient.CONFIG.save();
            refreshLabels();
        }).dimensions(center - 110, y + 56, 220, 20).build();
        addDrawableChild(reactionButton);

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> close())
                .dimensions(center - 110, y + 88, 220, 20).build());
    }

    private Text autoLabel() {
        return Text.literal("Auto Swap: " + (CombatUtilsClient.CONFIG.autoSwapEnabled ? "ON" : "OFF"));
    }

    private Text rangeLabel() {
        return Text.literal("Opponent range: " + CombatUtilsClient.CONFIG.rangeBlocks + " blocks");
    }

    private Text reactionLabel() {
        return Text.literal("Reaction delay: " + CombatUtilsClient.CONFIG.reactionTicks + " ticks");
    }

    private void refreshLabels() {
        autoButton.setMessage(autoLabel());
        rangeButton.setMessage(rangeLabel());
        reactionButton.setMessage(reactionLabel());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 4 - 24, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Chestplate near players; Elytra when clear."),
                width / 2, height / 4 - 8, 0xAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }
}

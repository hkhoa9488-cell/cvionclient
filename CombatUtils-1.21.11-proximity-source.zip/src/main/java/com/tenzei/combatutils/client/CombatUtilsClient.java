package com.tenzei.combatutils.client;

import com.mojang.blaze3d.platform.InputUtil;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class CombatUtilsClient implements ClientModInitializer {
    private static KeyBinding manualSwapKey;
    private static KeyBinding autoToggleKey;

    public static final ModConfig CONFIG = ModConfig.load();
    private static final ElytraSwap SWAP = new ElytraSwap();
    private static final FreeFall FREE_FALL = new FreeFall();

    @Override
    public void onInitializeClient() {
        manualSwapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.combat-utils.swap_elytra",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                KeyBinding.Category.MISC
        ));
        autoToggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.combat-utils.toggle_auto_swap",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(CombatUtilsClient::tick);
    }

    private static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null || client.interactionManager == null) {
            FREE_FALL.reset();
            return;
        }

        while (manualSwapKey.wasPressed()) {
            boolean changed = SWAP.toggleChestEquipment(client);
            client.player.sendMessage(Text.literal(
                    changed ? "Combat Utils: trang bị đã đổi." :
                            "Combat Utils: cần Elytra/giáp ngực trong hotbar."
            ), true);
        }

        while (autoToggleKey.wasPressed()) {
            CONFIG.autoSwapEnabled = !CONFIG.autoSwapEnabled;
            CONFIG.save();
            client.player.sendMessage(Text.literal(
                    "Auto Swap: " + (CONFIG.autoSwapEnabled ? "ON" : "OFF")
            ), true);
        }

        FREE_FALL.tick(client);
        SWAP.tickProximity(client, CONFIG);
    }
}

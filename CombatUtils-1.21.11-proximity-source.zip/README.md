# Combat Utils 1.21.11 — proximity swap

Features:
- `G`: manually toggle Elytra / chestplate using a matching item in the hotbar.
- `H`: toggle proximity auto-swap.
- When enabled, swap to a chestplate when another non-spectator player is within the configured radius.
- Swap back to Elytra when no other player is within range.
- Free-fall notification only; no MaceAttack, target locking, aiming, or attack automation.
- Mod Menu settings: enable/disable auto swap, change radius (2–32 blocks), and reaction delay (0–5 ticks).
- Config saved to `config/combat-utils.properties`.

The auto swap is OFF by default. The proximity behavior may be considered an advantage on some multiplayer servers; use only where client-side equipment automation is permitted.

## Build
Requires JDK 21 and Gradle. Run:
`gradle build --no-daemon`

Expected output:
`build/libs/combat-utils-1.1.0.jar`

This source has not been compiled in this environment. If GitHub Actions fails, inspect the Gradle error log; version coordinates or Minecraft 1.21.11 API signatures may need adjustment.

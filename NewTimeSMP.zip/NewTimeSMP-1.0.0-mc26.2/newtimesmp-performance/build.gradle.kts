dependencies {
    api(project(":newtimesmp-api"))
    implementation(project(":newtimesmp-core"))
    implementation(project(":newtimesmp-observability"))
    compileOnly(libs.slf4j.api)

    testImplementation(libs.slf4j.api)
    testImplementation(libs.junit.jupiter)
    testImplementation(libs.assertj.core)
    testRuntimeOnly(libs.slf4j.simple)
}

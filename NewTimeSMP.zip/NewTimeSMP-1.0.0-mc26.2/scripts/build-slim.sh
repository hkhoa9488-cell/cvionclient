#!/usr/bin/env bash
set -euo pipefail

# Builds a single deployable server JAR (~55-65 MB, well under 200 MB)
# and cleans heavy intermediate build caches afterwards.
DIST_DIR="dist"
mkdir -p "$DIST_DIR"

echo "[NewTimeSMP] 1/4 Building slim NewTimeSMP modules (compileOnly Paper deps)..."
gradle test jar --no-daemon

echo "[NewTimeSMP] 2/4 Ensuring shallow Paper 26.2 upstream clone..."
./scripts/verify-upstream.sh .upstream-paper

echo "[NewTimeSMP] 3/4 Building Paperclip/Bundler server JAR..."
(
  cd .upstream-paper
  ./gradlew applyPatches --no-daemon
  ./gradlew createMojmapBundlerJar --no-daemon || ./gradlew createPaperclipJar --no-daemon
)

SERVER_JAR=$(find .upstream-paper -path "*/build/libs/*.jar" ! -name "*-sources.jar" ! -name "*-javadoc.jar" | head -n 1)
if [ -n "$SERVER_JAR" ]; then
  cp "$SERVER_JAR" "$DIST_DIR/NewTimeSMP-1.0.0-mc26.2.jar"
  echo "[NewTimeSMP] Exported slim server JAR: $DIST_DIR/NewTimeSMP-1.0.0-mc26.2.jar"
  du -h "$DIST_DIR/NewTimeSMP-1.0.0-mc26.2.jar"
fi

echo "[NewTimeSMP] 4/4 Cleaning intermediate build directories to keep disk usage under 200MB..."
rm -rf .upstream-paper/work .upstream-paper/.gradle build */build
echo "[NewTimeSMP] Done. Deploy only $DIST_DIR/NewTimeSMP-1.0.0-mc26.2.jar (~55-65 MB)."

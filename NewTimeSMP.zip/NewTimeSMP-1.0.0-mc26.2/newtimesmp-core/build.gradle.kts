val newtimesmpVersion: String by project
val minecraftVersion: String by project

dependencies {
    api(project(":newtimesmp-api"))
    compileOnly(libs.snakeyaml)
    compileOnly(libs.slf4j.api)

    testImplementation(libs.snakeyaml)
    testImplementation(libs.slf4j.api)
    testImplementation(libs.junit.jupiter)
    testImplementation(libs.assertj.core)
    testRuntimeOnly(libs.slf4j.simple)
}

tasks.processResources {
    inputs.property("version", newtimesmpVersion)
    inputs.property("minecraftVersion", minecraftVersion)
    filesMatching("newtimesmp-build.properties") {
        expand(
            "version" to newtimesmpVersion,
            "minecraftVersion" to minecraftVersion
        )
    }
}

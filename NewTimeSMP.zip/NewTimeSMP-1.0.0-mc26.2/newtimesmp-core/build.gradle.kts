dependencies {
    api(project(":newtimesmp-api"))
    compileOnly(libs.snakeyaml)
    compileOnly(libs.slf4j.api)

    testImplementation(libs.snakeyaml)
    testImplementation(libs.slf4j.api)
    testImplementation(libs.junit.jupiter)
    testImplementation(libs.assertj.core)
    testRuntimeOnly(libs.slf4j.simple)
}

tasks.processResources {
    filesMatching("newtimesmp-build.properties") {
        expand(
            "version" to project.findProperty("newtimesmpVersion").toString(),
            "minecraftVersion" to project.findProperty("minecraftVersion").toString()
        )
    }
}

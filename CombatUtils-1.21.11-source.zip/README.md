# Combat Utils 1.21.11 — source scaffold

This trimmed project contains only:
- Manual Elytra/chestplate toggle (default `G`)
- Free-fall detection and action-bar notification
- Optional auto-swap to a chestplate when free-fall is detected (default toggle `H`, OFF by default)

Removed entirely:
- `MaceAttack`
- target selection and attack automation
- combat/aim logic

## Requirements
- JDK 21
- Gradle (or generate/use the Gradle wrapper)
- Fabric Loom and Fabric API versions matching Minecraft 1.21.11

## Build
From this folder, run:
`gradle build`

The output JAR should be in `build/libs/`.

## Important
This is a source scaffold and has not been compiled in this environment. If the selected Yarn/Fabric versions are unavailable or an API signature differs for your exact 1.21.11 toolchain, adjust `gradle.properties` and resolve compile errors before installing it. Test first in a local world or server where the mod is permitted.

Auto swap is OFF by default. It only swaps to a chestplate if the player is wearing an Elytra and a supported chestplate is in the hotbar. It does not attack or target other players.

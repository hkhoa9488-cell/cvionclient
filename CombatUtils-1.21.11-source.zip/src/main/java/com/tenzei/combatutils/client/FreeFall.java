package com.tenzei.combatutils.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public final class FreeFall {
    private static final double FALL_SPEED_THRESHOLD = -0.5;
    private static final int AUTO_SWAP_COOLDOWN_TICKS = 30;

    private int cooldownTicks = 0;
    private boolean wasFalling = false;

    public void tick(MinecraftClient client, boolean autoSwapEnabled, ElytraSwap swap) {
        if (client.player == null) return;

        if (cooldownTicks > 0) cooldownTicks--;

        boolean falling = !client.player.isOnGround()
                && !client.player.isFallFlying()
                && client.player.getVelocity().y < FALL_SPEED_THRESHOLD;

        if (falling && !wasFalling) {
            client.player.sendMessage(Text.literal("Free Fall: đang rơi."), true);
        }

        if (autoSwapEnabled && falling && cooldownTicks == 0) {
            if (swap.swapToChestplate(client)) {
                cooldownTicks = AUTO_SWAP_COOLDOWN_TICKS;
            }
        }

        wasFalling = falling;
    }
}

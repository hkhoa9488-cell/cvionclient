package com.tenzei.combatutils.client;

import com.mojang.blaze3d.platform.InputUtil;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class CombatUtilsClient implements ClientModInitializer {
    private static KeyBinding swapKey;
    private static KeyBinding autoToggleKey;
    private static final ElytraSwap SWAP = new ElytraSwap();
    private static final FreeFall FREE_FALL = new FreeFall();
    private static boolean autoSwapEnabled = false;

    @Override
    public void onInitializeClient() {
        swapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.combat-utils.swap_elytra",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                KeyBinding.Category.MISC
        ));
        autoToggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.combat-utils.toggle_auto_swap",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> tick(client));
    }

    private static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null || client.interactionManager == null) {
            return;
        }

        while (swapKey.wasPressed()) {
            boolean changed = SWAP.toggleChestEquipment(client);
            client.player.sendMessage(Text.literal(
                    changed ? "Combat Utils: trang bị đã đổi." :
                            "Combat Utils: cần Elytra/giáp ngực trong hotbar."
            ), true);
        }

        while (autoToggleKey.wasPressed()) {
            autoSwapEnabled = !autoSwapEnabled;
            client.player.sendMessage(Text.literal(
                    "Combat Utils Auto Swap: " + (autoSwapEnabled ? "ON" : "OFF")
            ), true);
        }

        FREE_FALL.tick(client, autoSwapEnabled, SWAP);
    }
}

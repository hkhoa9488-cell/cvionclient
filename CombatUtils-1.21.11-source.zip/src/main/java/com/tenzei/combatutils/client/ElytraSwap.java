package com.tenzei.combatutils.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public final class ElytraSwap {
    private static final int CHEST_SLOT_ID = 6;

    /**
     * Manually toggles between an equipped Elytra and a chestplate,
     * using an appropriate item in the hotbar.
     */
    public boolean toggleChestEquipment(MinecraftClient client) {
        if (client.player == null || client.interactionManager == null) return false;

        ItemStack equipped = client.player.getEquippedStack(EquipmentSlot.CHEST);
        boolean wearingElytra = equipped.isOf(Items.ELYTRA);

        for (int hotbar = 0; hotbar < 9; hotbar++) {
            ItemStack stack = client.player.getInventory().getStack(hotbar);
            boolean isTarget = wearingElytra ? isChestplate(stack) : stack.isOf(Items.ELYTRA);

            if (isTarget) {
                client.interactionManager.clickSlot(
                        client.player.playerScreenHandler.syncId,
                        CHEST_SLOT_ID,
                        hotbar,
                        SlotActionType.SWAP,
                        client.player
                );
                return true;
            }
        }
        return false;
    }

    /**
     * Replaces an equipped Elytra with a chestplate if one is in the hotbar.
     * Does nothing if the player already wears a chestplate or no target exists.
     */
    public boolean swapToChestplate(MinecraftClient client) {
        if (client.player == null || client.interactionManager == null) return false;
        ItemStack equipped = client.player.getEquippedStack(EquipmentSlot.CHEST);
        if (!equipped.isOf(Items.ELYTRA)) return false;

        for (int hotbar = 0; hotbar < 9; hotbar++) {
            if (isChestplate(client.player.getInventory().getStack(hotbar))) {
                client.interactionManager.clickSlot(
                        client.player.playerScreenHandler.syncId,
                        CHEST_SLOT_ID,
                        hotbar,
                        SlotActionType.SWAP,
                        client.player
                );
                return true;
            }
        }
        return false;
    }

    private static boolean isChestplate(ItemStack stack) {
        return stack.isOf(Items.LEATHER_CHESTPLATE)
                || stack.isOf(Items.CHAINMAIL_CHESTPLATE)
                || stack.isOf(Items.IRON_CHESTPLATE)
                || stack.isOf(Items.GOLDEN_CHESTPLATE)
                || stack.isOf(Items.DIAMOND_CHESTPLATE)
                || stack.isOf(Items.NETHERITE_CHESTPLATE);
    }
}
